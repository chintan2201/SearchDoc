﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_Layer_Patient : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    //protected void btnProfile_Click(object sender, EventArgs e)
    //{
    //   // Response.Redirect(URL.patient);
    //    Response.Redirect("Patient.aspx");
    //}
    protected void btnFinddoctor_Click(object sender, EventArgs e)
    {
        Response.Redirect(URL.Searching_Patient);
    }
    protected void btnTakeappointment_Click(object sender, EventArgs e)
    {
        Response.Redirect(URL.Searching_Patient);
    }
    protected void btnOrgandonate_Click(object sender, EventArgs e)
    {
        Response.Redirect(URL.organDonate_Patient);
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {

        Session.Clear();
        Session.RemoveAll();
        Session.Abandon();
        Response.Redirect(URL.home);
     
    }

    protected void btnProfile_Click(object sender, EventArgs e)
    {
        Response.Redirect("Patient.aspx");
    }
}
