﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using BusinessLogic;
using DataAccess;

public partial class Application_Layer_Dr : System.Web.UI.Page
{
    Dr_Profile_bl dr =new Dr_Profile_bl();
    Dr_Updt_bl drupdt = new Dr_Updt_bl();
    Drp_Fill_bl drp = new Drp_Fill_bl();
    logicDropdown l2 = new logicDropdown();
    protected void Page_Load(object sender, EventArgs e)
    {
      //  Response.Redirect("schedule.aspx?RegistrationId=" + Session["RegistrationId"]);
        if (Session["RegistrationId"] == null)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect(URL.home);
        }
        if (!IsPostBack)
        {
            drpState.DataSource = l2.StateLogic();
            drpState.DataTextField = "State";
            drpState.DataValueField = "pkStateId";
            drpState.DataBind();

            drpSpeciality.DataSource = drp.spec();
            drpSpeciality.DataTextField = "Speciality";
            drpSpeciality.DataValueField = "pkSpecialityId";
            drpSpeciality.DataBind();
            
                drpGraduationCollege.DataSource = drp.gradclg();
                drpGraduationCollege.DataTextField = "Graduation_College";
                drpGraduationCollege.DataValueField = "pkGraduationCollege";
                drpGraduationCollege.DataBind();

                drpPgCollege.DataSource = drp.pgclg();
                drpPgCollege.DataTextField = "PG_College";
                drpPgCollege.DataValueField = "pkpgCollege";
                drpPgCollege.DataBind();
            
            txtFastName.Enabled = false;
            txtLastName.Enabled = false;
            txtDateofBirth.Enabled = false;
            txtEmail.Enabled = false;
            txtStreet1.Enabled = false;
            txtStreet2.Enabled = false;
            txtPincode.Enabled = false;
            txtContactnumber.Enabled = false;
            drpBloodGroup.Enabled = false;
            drpCity.Enabled = false;
            drpState.Enabled = false;
            drpCountry.Enabled = false;
            drpGender.Enabled = false;

            drpGraduationCollege.Enabled = false;
            drpPgCollege.Enabled = false;
            drpSpeciality.Enabled = false;
            txtPgYear.Enabled = false;
            txtGraduationYear.Enabled = false;

            dr.display(Convert.ToInt16(Session["RegistrationId"]));

            txtFastName.Text = Session["fname"].ToString();
            txtLastName.Text = Session["lname"].ToString();
            txtDateofBirth.Text = Session["dob"].ToString();
            drpGender.SelectedValue = Session["gen"].ToString();
            txtEmail.Text = Session["email"].ToString();
            drpBloodGroup.SelectedValue = Session["bg"].ToString();
            txtStreet1.Text = Session["Add1"].ToString();
            txtStreet2.Text = Session["Add2"].ToString();
            drpCity.SelectedIndex = Convert.ToInt16(Session["city"]);
            txtPincode.Text = Session["pin"].ToString();
            drpState.SelectedIndex = Convert.ToInt16(Session["state"]);
            drpCountry.SelectedIndex = Convert.ToInt16(Session["country"]);
            txtContactnumber.Text = Session["mb"].ToString();
            imgDoctor.ImageUrl = Session["photo"].ToString();

            lblDocname.Text = Session["fname"].ToString();
            //txtfname.Text = Session["fname"].ToString();

            txtGraduationYear.Text = Session["gradyr"].ToString();
            txtPgYear.Text = Session["pgyr"].ToString();
            drpPgCollege.SelectedIndex = Convert.ToInt16(Session["fkpgclg"]);
            drpGraduationCollege.SelectedIndex = Convert.ToInt16(Session["fkgradclg"]);
            drpSpeciality.SelectedIndex = Convert.ToInt16(Session["spec"]);
            


            
        }


    }
    protected void btnEditprofile_Click(object sender, EventArgs e)
    {
        //Response.Redirect(URL.EditProfileDoctor);
        txtFastName.Enabled = true;
        txtLastName.Enabled = true;
        txtDateofBirth.Enabled = true;
        //        txtEmail.Enabled = true;
        txtStreet1.Enabled = true;
        txtStreet2.Enabled = true;
        txtPincode.Enabled = true;
        txtContactnumber.Enabled = true;
        drpBloodGroup.Enabled = true;
        drpCity.Enabled = true;
        drpState.Enabled = true;
        drpCountry.Enabled = true;
        drpGender.Enabled = true;

        drpGraduationCollege.Enabled = true;
        drpPgCollege.Enabled = true;
        drpSpeciality.Enabled = true;
        txtPgYear.Enabled = true;
        txtGraduationYear.Enabled = true;



    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        drupdt.FirstName = txtFastName.Text;
        drupdt.LastName = txtLastName.Text;
        drupdt.DateOfBirth = txtDateofBirth.Text;
        drupdt.Gender = drpGender.SelectedValue.ToString();
        drupdt.Email = txtEmail.Text;
        drupdt.BloodGroup = drpBloodGroup.SelectedValue.ToString();
        drupdt.Street1 = txtStreet1.Text;
        drupdt.Street2 = txtStreet2.Text;
        drupdt.fkCityId = Convert.ToInt16(drpCity.SelectedValue);
        drupdt.PinCode = Convert.ToInt64(txtPincode.Text);
        drupdt.fkStateId = Convert.ToInt16(drpState.SelectedValue);
        drupdt.fkCountryId = Convert.ToInt16(drpCountry.SelectedValue);
        drupdt.ContactNumber = Convert.ToInt64(txtContactnumber.Text);
        drupdt.SpecificDetail = null;

        drupdt.Graduation_College = Convert.ToInt16(drpGraduationCollege.SelectedValue);
        drupdt.Graduation_Year = Convert.ToInt16(txtGraduationYear.Text);
        drupdt.PG_College = Convert.ToInt16(drpPgCollege.SelectedValue);
        drupdt.PG_Year = Convert.ToInt16(txtPgYear.Text);
        drupdt.fkSpecialityId = Convert.ToInt16(drpSpeciality.SelectedValue);

        
        drupdt.updt(Convert.ToInt16(Session["RegistrationId"]));

        lblSuccessdul.Visible = true;
    }
    protected void drpGraduationCollege_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void drpState_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpCity.Items.Clear();
        drpCity.Items.Add("--Select City--");
        l2.pkStateId = Convert.ToInt32(drpState.SelectedValue);
        drpCity.DataSource = l2.CityLogic(Convert.ToInt32(drpState.SelectedValue));
        drpCity.DataTextField = "City";
        drpCity.DataValueField = "pkCityId";
        drpCity.DataBind();

    }

    protected void btnChangepwd_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChangepasswordDoc.aspx");
    }
}