﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using BusinessLogic;
using DataAccess;

public partial class Application_Layer_Registration : System.Web.UI.Page
{
   
    PatientRugistrationSubmitLogic pl = new PatientRugistrationSubmitLogic();
    DoctorRegistrationSubmitLogic dl = new DoctorRegistrationSubmitLogic();
    logicDropdown l2 = new logicDropdown();
    Drp_Fill_bl drp = new Drp_Fill_bl();
    orgndrp orgn = new orgndrp();
    LoginLogic l1 = new LoginLogic();
    string url;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        PnlDoctor.Visible = false;
        pnlPatient.Visible = false;
        lblFupError.Visible = false;
        pnlorgan.Visible = false;
        //url = "F:/navo_project/pr1/project/project final/SearchDoc/Application Layer/photos";
        url="C:/Documents and Settings/user/Desktop/SearchDoc/Application Layer/photos";

        if (!IsPostBack)
        {
            drporgnrelation.DataSource = orgn.relation();
            drporgnrelation.DataTextField = "Relation";
            drporgnrelation.DataValueField = "pkRelationID";
            drporgnrelation.DataBind();

            drporgntype.DataSource = orgn.organtype();
            drporgntype.DataTextField = "Organtype";
            drporgntype.DataValueField = "pkOrganTypeID";
            drporgntype.DataBind();

            drpGraduationCollege.DataSource = drp.gradclg();
            drpGraduationCollege.DataTextField = "Graduation_College";
            drpGraduationCollege.DataValueField = "pkGraduationCollege";
            drpGraduationCollege.DataBind();

            drpPgCollege.DataSource = drp.pgclg();
            drpPgCollege.DataTextField = "PG_College";
            drpPgCollege.DataValueField = "pkpgCollege";
            drpPgCollege.DataBind();

            drpque.DataSource = drp.que();
            drpque.DataTextField = "Que";
            drpque.DataValueField = "pkQueId";
            drpque.DataBind();

            drpState.DataSource = l2.StateLogic();
            drpState.DataTextField = "State";
            drpState.DataValueField = "pkStateId";
            drpState.DataBind();
        }
    }

    protected void drpUserType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpUserType.SelectedValue=="1")
        {
            pnlPatient.Visible = true;
        }

        else if (drpUserType.SelectedValue == "2")
        {
            PnlDoctor.Visible = true;
        }
        else if (drpUserType.SelectedValue == "4")
        {
            pnlorgan.Visible = true;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (drpUserType.SelectedValue == "1")
        {
            pl.UserName = txtUserName.Text;
            pl.fkUserTypeId = drpUserType.SelectedIndex;
            pl.FirstName = txtFastName.Text;
            pl.LastName = txtLastName.Text;
            pl.DateOfBirth = txtDateofBirth.Text;
            pl.Gender = Convert.ToString(drpGender.SelectedItem);
            pl.BloodGroup = Convert.ToString(drpBloodGroup.SelectedItem);
            pl.Email = txtEmail.Text;
            pl.Password = txtPassword.Text;
            pl.Street1 = txtStreet1.Text;
            pl.Street2 = txtStreet2.Text;
            pl.fkCityId = Convert.ToInt32(drpCity.SelectedValue);
            pl.fkCountryId = Convert.ToInt32(drpCountry.SelectedValue);
            pl.fkStateId = Convert.ToInt32(drpState.SelectedValue);
            pl.PinCode = Convert.ToInt32(txtPincode.Text);
            pl.ContactNumber = Convert.ToInt64(txtContactnumber.Text);
            pl.SpecificDetail = txtPatientDetail.Text;
            pl.fkqueid = Convert.ToInt16(drpque.SelectedValue);
            pl.ans = txtans.Text;
            pl.PatientRegistrationLogic(txtUserName.Text, drpUserType.SelectedIndex, txtFastName.Text, txtLastName.Text, txtDateofBirth.Text, Convert.ToString(drpGender.SelectedItem), Convert.ToString(drpBloodGroup.SelectedItem), txtEmail.Text, txtPassword.Text, pl.fkqueid, pl.ans, txtStreet1.Text, txtStreet2.Text, drpCity.SelectedValue, Convert.ToInt32(drpCountry.SelectedValue), Convert.ToInt32(drpState.SelectedValue), Convert.ToInt32(txtPincode.Text), Convert.ToInt64(txtContactnumber.Text), txtPatientDetail.Text);
            Response.Redirect(URL.home);
        }

        if (drpUserType.SelectedValue == "2")
        {
            fileupload();
            dl.UserName = txtUserName.Text;
            dl.fkUserTypeId = drpUserType.SelectedIndex;
            dl.FirstName = txtFastName.Text;
            dl.LastName = txtLastName.Text;
            dl.fkSpecialityId = Convert.ToInt32(drpSpeciality.SelectedValue);
            dl.DateOfBirth = txtDateofBirth.Text;
            dl.Gender = Convert.ToString(drpGender.SelectedItem);
            dl.BloodGroup = Convert.ToString(drpBloodGroup.SelectedItem);
            dl.Email = txtEmail.Text;
            dl.Password = txtPassword.Text;
            dl.fkqueid = Convert.ToInt16(drpque.SelectedValue);
            dl.ans = txtans.Text;
            dl.Street1 = txtStreet1.Text;
            dl.Street2 = txtStreet2.Text;
            dl.fkCityId = Convert.ToInt32(drpCity.SelectedValue);
            dl.fkCountryId = Convert.ToInt32(drpCountry.SelectedValue);
            dl.fkStateId = Convert.ToInt32(drpState.SelectedValue);
            dl.PinCode = Convert.ToInt32(txtPincode.Text);
            dl.ContactNumber = Convert.ToInt64(txtContactnumber.Text);
            dl.Photo = (url).ToString();
            //dl.fkDoctorId = Convert.ToInt32(txtFkdoctorId.Text);
            dl.Graduation_Year = Convert.ToInt32(txtGraduationYear.Text);
            dl.Graduation_College = Convert.ToInt16(drpGraduationCollege.SelectedValue);
            dl.PG_Year = Convert.ToInt32(txtPgYear.Text);
            dl.PG_College = Convert.ToInt16(drpPgCollege.SelectedValue);
            dl.DoctorRegistrationLogic(dl.UserName, dl.fkUserTypeId, dl.FirstName, dl.LastName, dl.fkSpecialityId, dl.DateOfBirth, dl.Gender, dl.BloodGroup, dl.Email, dl.Password, dl.fkqueid, dl.ans, dl.Street1, dl.Street2, dl.fkCityId, dl.fkCountryId, dl.fkStateId, dl.PinCode, dl.ContactNumber, dl.Photo, dl.Graduation_Year, dl.Graduation_College, dl.PG_Year, dl.PG_College);
            // dl.DoctorRegistrationLogic();
            Response.Redirect(URL.home);
        }
        if (drpUserType.SelectedValue == "4")
        {
            pnlorgan.Visible = true;
            orgn.UserName = txtUserName.Text;
            orgn.fkUserTypeId = Convert.ToInt32(drpUserType.SelectedValue);
            orgn.FirstName = txtFastName.Text; ;
            orgn.LastName = txtLastName.Text;
            orgn.DateOfBirth = txtDateofBirth.Text;
            orgn.Gender = Convert.ToString(drpGender.SelectedItem);
            orgn.BloodGroup = Convert.ToString(drpBloodGroup.SelectedItem);
            orgn.Email = txtEmail.Text;
            orgn.Password = txtPassword.Text;
            orgn.fkqueid = Convert.ToInt16(drpque.SelectedValue);
            orgn.ans = txtans.Text;
            orgn.Street1 = txtStreet1.Text;
            orgn.Street2 = txtStreet2.Text;
            orgn.fkCityId = Convert.ToInt32(drpCity.SelectedValue);
            orgn.fkCountryId = Convert.ToInt32(drpCountry.SelectedValue);
            orgn.fkStateId = Convert.ToInt32(drpState.SelectedValue);
            orgn.PinCode = Convert.ToInt32(txtPincode.Text);
            orgn.ContactNumber = Convert.ToInt64(txtContactnumber.Text);
            orgn.ContactPersonName = txtorgncntactprsn.Text;
            orgn.ContactPersonMobile = Convert.ToInt64(txtorgncntctmobile.Text);
            orgn.ContactPersonEmail = txtorgncntctemail.Text;
            orgn.fkRelationID = Convert.ToInt32(drporgnrelation.SelectedValue);
            orgn.fkOrganTypeID = Convert.ToInt32(drporgntype.SelectedValue);
            orgn.OrganRegistration(orgn.UserName, orgn.fkUserTypeId, orgn.FirstName, orgn.LastName, orgn.DateOfBirth, orgn.Gender, orgn.BloodGroup, orgn.Email, orgn.Password, orgn.fkqueid, orgn.ans, orgn.Street1, orgn.Street2, orgn.fkCityId, orgn.fkCountryId, orgn.fkStateId, orgn.PinCode, orgn.ContactNumber, orgn.ContactPersonName, orgn.ContactPersonMobile, orgn.ContactPersonEmail, orgn.fkRelationID, orgn.fkOrganTypeID);
            Response.Redirect(URL.home);

        }
    }

  
   public void fileupload()
   {
       //if (!Directory.Exists("Doctor_Photo" + "//" + txtEmail.Text))
       //{
       //    Directory.CreateDirectory("Doctor_Photo" + "//" + txtEmail.Text);
       //}
       if (fupPhoto.HasFile)
       {

           string file = fupPhoto.FileName;
           if (file.Contains(".jpg") || file.Contains(".gif") || file.Contains(".jpeg") || file.Contains(".png"))
           {
               string fpath = Server.MapPath("photos");
               string concate = fpath + "// " + file;
               fupPhoto.SaveAs(concate);

           }
           else
           {
               lblFupError.Visible = true;
               lblFupError.Text = "Not correct photo format.";
           }

       }
   }
   

   protected void drpState_SelectedIndexChanged(object sender, EventArgs e)
   {
       drpCity.Items.Clear();
       drpCity.Items.Add("--Select City--");
       l2.pkStateId = Convert.ToInt32(drpState.SelectedValue);
       drpCity.DataSource = l2.CityLogic(Convert.ToInt32(drpState.SelectedValue));
       drpCity.DataTextField = "City";
       drpCity.DataValueField = "pkCityId";
       drpCity.DataBind();

   }
}