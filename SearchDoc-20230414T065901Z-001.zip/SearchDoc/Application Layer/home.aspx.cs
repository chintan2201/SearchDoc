﻿
using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;
using BusinessLogic;

public partial class home : System.Web.UI.Page
{
    LoginLogic l1 = new LoginLogic();
    login_data d1 = new login_data();
    logicDropdown l2 = new logicDropdown();
    protected void Page_Load(object sender, EventArgs e)
    {
      
        if (IsPostBack)
        {
            lblWrongUserNamePassword.Visible = true;
        }

        else if(!IsPostBack)
        {

            drpSpeciality.DataSource = l2.specialityLogic();
            drpSpeciality.DataTextField = "Speciality";
            drpSpeciality.DataValueField = "pkSpecialityId";
            drpSpeciality.DataBind();

            drpState.DataSource = l2.StateLogic();
            drpState.DataTextField = "State";
            drpState.DataValueField = "pkStateId";
            drpState.DataBind();

            drpHospital.DataSource = l2.HospitalLogic();
            drpHospital.DataTextField = "Hospital_Name";
            drpHospital.DataValueField = "pkHospitalId";
            drpHospital.DataBind();

            drpDoctor.DataSource = l2.DoctorLogic();
            drpDoctor.DataTextField = "First Name";
            drpDoctor.DataValueField = "pkDoctorId";
            drpDoctor.DataBind();

           
        }

       
    }

    #region Button Click Event
    /// <summary>
    /// Login button Event
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        l1.UserName = txtUserName.Text;
        l1.Password = txtPassword.Text;
        l1.Login_l(txtUserName.Text, txtPassword.Text);
       
        
      
    }
    #endregion
    protected void btnFindDoctor_Click(object sender, EventArgs e)
    {
        if (drpState.SelectedValue != "0" && drpCity.SelectedValue == "--Select City--")
        {
            lblSelectCity.Visible = true;
        }
        else
        {
           lblSelectCity.Visible = false;
           Session["speciality"] = drpSpeciality.SelectedValue;
           Session["hospital"] = drpHospital.SelectedValue;
           Session["city"] = drpCity.SelectedValue;
           Session["doctor"] = drpDoctor.SelectedItem;
           Session["state"] = drpState.SelectedValue;

           Session["city1"] = drpCity.SelectedItem;
           Session["state1"] = drpState.SelectedItem;
            Response.Redirect(URL.searching);
        }

            
            
       
    }
    protected void lnkForgotPassword_Click(object sender, EventArgs e)
    {
        Response.Redirect(URL.forgot_password);
    }
    protected void btnCreateAccount_Click(object sender, EventArgs e)
    {
        Response.Redirect(URL.registration);
    }
   
    protected void drpState_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpCity.Items.Clear();
        drpCity.Items.Add("--Select City--");
        l2.pkStateId = Convert.ToInt32(drpState.SelectedValue);
        drpCity.DataSource = l2.CityLogic(Convert.ToInt32(drpState.SelectedValue));
        drpCity.DataTextField = "City";
        drpCity.DataValueField = "pkCityId";
        drpCity.DataBind();

    }
   
}