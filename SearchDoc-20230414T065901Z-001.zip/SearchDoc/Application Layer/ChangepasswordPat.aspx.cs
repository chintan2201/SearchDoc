﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_Layer_ChangepasswordPat : System.Web.UI.Page
{

    chngepwd_bl pwdbl = new chngepwd_bl();
    string pwd;
    protected void Page_Load(object sender, EventArgs e)
    {

        lbldis.Visible = false;
        if (!IsPostBack)
        {
            lblorgnName.Text = Session["fname"].ToString();
            txtUserName1.Text = Session["email"].ToString();

            pwd = Session["Password"].ToString();
        }
    }
    protected void btnchang_Click(object sender, EventArgs e)
    {
        pwdbl.email = txtUserName1.Text;
        pwdbl.passwrd = txtoldpwd.Text;

        if (txtoldpwd.Text == Session["Password"].ToString())
        {
            pwdbl.email = txtUserName1.Text;
            pwdbl.pass = txtnewpwd.Text;
            pwdbl.cnfrmpwd = txtretypwd.Text;
            pwdbl.loguser();
            pwdbl.updtpwd();
            lblpwd.Text = "Password changed!!";
        }
        lbldis.Visible = true;
        lbldis.Text = "Your Password Has been Changed";
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtoldpwd.Text = " ";
        txtnewpwd.Text = " ";
        txtretypwd.Text = " ";
    }
}