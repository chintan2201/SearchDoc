﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;
using BusinessLogic;
using System.Collections.Generic;


public partial class Application_Layer_schedule : System.Web.UI.Page
{
    CreateScheduleLogic sl = new CreateScheduleLogic();
    ScheduleDataAccess sd = new ScheduleDataAccess();
    SubmitScheduleDataLogic sa = new SubmitScheduleDataLogic();
    Drp_Fill_bl drp = new Drp_Fill_bl();
    schedule_bl bl = new schedule_bl();
    login_data l = new login_data();
    forDoctorId_bl drid = new forDoctorId_bl();  
    
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["RegistrationId"] == null)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect(URL.home);
        }
        int a = Convert.ToInt16(Session["RegistrationId"]);
        //int a = Convert.ToInt16(Request.QueryString["RegistrationId"]);
        if (!IsPostBack)
        {
            drpcity.DataSource = drp.city();
            drpcity.DataTextField = "City";
            drpcity.DataValueField = "pkCityId";
            drpcity.DataBind();

            drpState.DataSource = drp.state();
            drpState.DataTextField = "State";
            drpState.DataValueField = "pkStateId";
            drpState.DataBind();

            drpAddPlace.DataSource = drp.hospital();
            drpAddPlace.DataTextField = "Hospital_Name";
            drpAddPlace.DataValueField = "pkHospitalId";
            drpAddPlace.DataBind();

            grdSchedulehospital.DataBind();
            
        }
    }

    protected void drpAddPlace_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }

    #region Add Place
    /// <summary>
    /// for add place
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnAddPlace_Click(object sender, EventArgs e)
    {
        
        //if (drpAddPlace.SelectedValue == "others")
        //{
            
        //    sl.Day =Convert.ToString( drpDay.SelectedItem);
        //    sl.FromTime =Convert.ToInt32(drpFrom.SelectedValue);
        //    sl.ToTime = Convert.ToInt32(drpTo.SelectedValue);
        //    sl.Place = drpAddPlace.SelectedValue.ToString();
        //    //sl.ClinicName = txtClinicName.Text;
        //    //sl.StreetName = txtStreetName.Text;
        //    //sl.Area = txtClinicArea.Text;
        //    //sl.City = Convert.ToString(drpClinicCity.SelectedItem);
        //    //sl.State = Convert.ToString(drpClinicState.SelectedItem);
        //    sl.AddPlace(Convert.ToString(drpDay.SelectedValue), Convert.ToInt32(drpFrom.SelectedValue), Convert.ToInt32(drpTo.SelectedValue), Convert.ToString(drpAddPlace.SelectedItem), txtClinicName.Text, txtStreetName.Text, txtClinicArea.Text, Convert.ToString(drpClinicCity.SelectedItem), Convert.ToString(drpClinicState.SelectedItem));
        //    grdSchedule.Visible = true;
        //    grdSchedule.DataSource = (DataTable)Session["datatable"];
        //    grdSchedule.DataBind();
         
        //}
        

        //sl.fkDayId = Convert.ToInt32(drpDay.SelectedValue);
        //sl.fkCityId = Convert.ToInt32(drpcity.SelectedValue);
        //sl.fkStateId = Convert.ToInt32(drpState.SelectedValue);
        //sl.FromTime =Convert.ToInt32(drpFrom.SelectedValue);
        //sl.ToTime = Convert.ToInt32(drpTo.SelectedValue);
        //sl.fkRegistrationId = Convert.ToInt32(Session["RegistrationId"]);
        //sl.AddPlaceClinic();

        //grdSchedulehospital.Visible = true;
        //grdSchedulehospital.DataSource = (DataTable)Session["data"];
        //grdSchedulehospital.DataBind();

        int a = Convert.ToInt16(Session["RegistrationId"]);
        drid.fkRegistrationId = a;
        int aa = drid.drid();
        Session["drid"] = aa.ToString();
        //bl.fkRegistrationId = Convert.ToInt16(Session["RegistraionId"]);
        bl.FromTime = Convert.ToInt32(drpFrom.SelectedValue);
        bl.ToTime = Convert.ToInt32(drpTo.SelectedValue);
        bl.fkDayId = Convert.ToInt32(drpDay.SelectedValue);
        bl.fkhospitalId = Convert.ToInt16(drpAddPlace.SelectedValue);
        bl.fkRegistrationId = a;
        bl.fkCityId = Convert.ToInt32(drpcity.SelectedValue);
        bl.fkStateId = Convert.ToInt32(drpState.SelectedValue);
        bl.fkdrId = aa;
        bl.AddSchedule();

        //int b = Convert.ToInt16(Session["RegistrationId"]);
        //drid.fkRegistrationId = b;
        //int bb = drid.drid();
        //Session["drid"] = bb.ToString();
        grdSchedulehospital.DataBind();

        lblsuccess.Visible = true;
    }

    #endregion

    #region  clearcontrols
    public void ClearControls1()
    {
        drpDay.SelectedIndex= -1;
        drpFrom.SelectedIndex = -1;
        drpTo.SelectedIndex = -1;
        drpAddPlace.SelectedIndex = -1;
      
    }

    public void Clearcontrols2()
    {
        drpDay.SelectedIndex = -1;
        drpFrom.SelectedIndex = -1;
        drpTo.SelectedIndex = -1;

        drpAddPlace.SelectedIndex = -1;
    //    txtClinicName.Text = "";
    //    txtStreetName.Text = "";
    //    txtClinicArea.Text = "";
    //    drpClinicCity.SelectedIndex = -1;
    //    drpClinicState.SelectedIndex = -1;
    }

    #endregion


    #region Submit Data
    /// <summary>
/// Submit Data
/// </summary>
/// <param name="sender"></param>
/// <param name="e"></param>

    //protected void btnSubmit_Click(object sender, EventArgs e)
    //{
    //    //if (drpAddPlace.SelectedValue == "others")
    //    //{
    //    //    sl.Day = Convert.ToString(drpDay.SelectedItem);
    //    //    sl.FromTime = Convert.ToInt32(drpFrom.SelectedValue);
    //    //    sl.ToTime = Convert.ToInt32(drpTo.SelectedValue);
    //    //    sl.Place = drpAddPlace.SelectedValue.ToString();
    //    //    sl.ClinicName = txtClinicName.Text;
    //    //    sl.StreetName = txtStreetName.Text;
    //    //    sl.Area = txtClinicArea.Text;
    //    //    sl.City = Convert.ToString(drpClinicCity.SelectedItem);
    //    //    sl.State = Convert.ToString(drpClinicState.SelectedItem);

    //    //}
    //    //else
        
    //        sa.Day = Convert.ToInt16(drpDay.SelectedValue);
    //        sa.fkDoctorId = 5;
    //        sa.FromTime = Convert.ToInt32(drpFrom.SelectedValue);
    //        sa.ToTime = Convert.ToInt32(drpTo.SelectedValue);
    //        sa.Place = drpAddPlace.SelectedValue.ToString();
    //        sa.SubmitDataLogic(Convert.ToInt16(sa.fkDoctorId),Convert.ToInt32(drpDay.SelectedValue), Convert.ToInt32(drpFrom.SelectedValue), Convert.ToInt32(drpTo.SelectedValue), Convert.ToString(drpAddPlace.SelectedValue));
    //        ClearControls1();
        
    //}
    #endregion


    protected void btnyes_Click(object sender, EventArgs e)
    {
        Response.Redirect("Clinic_dr.aspx");
    }
   
}