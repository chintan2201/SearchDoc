﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_Layer_Admin : System.Web.UI.Page
{
    AdminDataContext obj = new AdminDataContext();
    tbl_Hospital hs = new tbl_Hospital();
    tbl_GraduationCollege gc = new tbl_GraduationCollege();
    tbl_PgCollege pgc = new tbl_PgCollege();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnInsertHospital_Click(object sender, EventArgs e)
    {
        hs.Hospital_Name = txtHospital.Text;
        hs.Hospital_Address = txtHospitalAddress.Text;
        obj.tbl_Hospitals.InsertOnSubmit(hs);
        obj.SubmitChanges();
        clearcontrols_1();
    }


    protected void btnInsertGraduationCollege_Click(object sender, EventArgs e)
    {
        gc.Graduation_College = txtGraduationCollege.Text;
        obj.tbl_GraduationColleges.InsertOnSubmit(gc);
        obj.SubmitChanges();
        clearcontrols_2();
    }
    protected void btnInsertPgCollege_Click(object sender, EventArgs e)
    {
        pgc.PG_College = txtPgCollege.Text;
        obj.tbl_PgColleges.InsertOnSubmit(pgc);
        obj.SubmitChanges();
        clearcontrols_3();
    }
  

   public void clearcontrols_1()
    {
        txtHospital.Text = "";
       txtHospitalAddress.Text="";
    }
   public void clearcontrols_2()
   {
       txtGraduationCollege.Text = "";
   }
   public void clearcontrols_3()
   {
       txtPgCollege.Text = "";
   }
 
}
