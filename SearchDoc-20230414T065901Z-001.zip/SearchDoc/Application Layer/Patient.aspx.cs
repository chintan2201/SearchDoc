﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using BusinessLogic;
using DataAccess;

public partial class Application_Layer_Patient : System.Web.UI.Page
{
    Patient_Profile_bl pt = new Patient_Profile_bl();
    Patient_Updt_bl ptupdt = new Patient_Updt_bl();
    logicDropdown l2 = new logicDropdown();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["RegistrationId"] == null)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect(URL.home);
        }
        else
        {

            if (!IsPostBack)
            {
                txtFastName.Enabled = false;
                txtLastName.Enabled = false;
                txtDateofBirth.Enabled = false;
                txtEmail.Enabled = false;
                txtStreet1.Enabled = false;
                txtStreet2.Enabled = false;
                txtPincode.Enabled = false;
                txtContactnumber.Enabled = false;
                drpBloodGroup.Enabled = false;
            drpCity.Enabled = false;
             //   txtCity.Enabled = false;
                drpState.Enabled = false;
                drpCountry.Enabled = false;
                drpGender.Enabled = false;

                drpState.DataSource = l2.StateLogic();
                drpState.DataTextField = "State";
                drpState.DataValueField = "pkStateId";
                drpState.DataBind();
                pt.display(Convert.ToInt16(Session["RegistrationId"]));

                txtFastName.Text = Session["fname"].ToString();
                txtLastName.Text = Session["lname"].ToString();
                txtDateofBirth.Text = Session["dob"].ToString();
                drpGender.SelectedValue = Session["gen"].ToString();
                txtEmail.Text = Session["email"].ToString();
                drpBloodGroup.SelectedValue = Session["bg"].ToString();
                txtStreet1.Text = Session["Add1"].ToString();
                txtStreet2.Text = Session["Add2"].ToString();
               // txtCity.Text=Session["city"].ToString();
                drpCity.SelectedValue = Convert.ToString(Session["city"]);
                txtPincode.Text = Session["pin"].ToString();
                drpState.SelectedIndex = Convert.ToInt16(Session["state"]);
                drpCountry.SelectedIndex = Convert.ToInt16(Session["country"]);
                txtContactnumber.Text = Session["mb"].ToString();

                lblPatName.Text = Session["fname"].ToString();
                //txtfname.Text = Session["fname"].ToString();
            }
            //else
            //{
            //    txtFastName.Enabled = false;
            //    txtLastName.Enabled = false;
            //    txtDateofBirth.Enabled = false;
            //    txtEmail.Enabled = false;
            //    txtStreet1.Enabled = false;
            //    txtStreet2.Enabled = false;
            //    txtPincode.Enabled = false;
            //    txtContactnumber.Enabled = false;
            //    drpBloodGroup.Enabled = false;
            //    drpCity.Enabled = false;
            //    drpState.Enabled = false;
            //    drpCountry.Enabled = false;
            //    drpGender.Enabled = false;

            //    drpState.DataSource = l2.StateLogic();
            //    drpState.DataTextField = "State";
            //    drpState.DataValueField = "pkStateId";
            //    drpState.DataBind();
            //    pt.display(Convert.ToInt16(Session["RegistrationId"]));

            //    txtFastName.Text = Session["fname"].ToString();
            //    txtLastName.Text = Session["lname"].ToString();
            //    txtDateofBirth.Text = Session["dob"].ToString();
            //    drpGender.SelectedValue = Session["gen"].ToString();
            //    txtEmail.Text = Session["email"].ToString();
            //    drpBloodGroup.SelectedValue = Session["bg"].ToString();
            //    txtStreet1.Text = Session["Add1"].ToString();
            //    txtStreet2.Text = Session["Add2"].ToString();
            //    drpCity.SelectedIndex = Convert.ToInt16(Session["city"]);
            //    txtPincode.Text = Session["pin"].ToString();
            //    drpState.SelectedIndex = Convert.ToInt16(Session["state"]);
            //    drpCountry.SelectedIndex = Convert.ToInt16(Session["country"]);
            //    txtContactnumber.Text = Session["mb"].ToString();

            //    lblPatName.Text = Session["fname"].ToString();
            //}

        }
    }



    protected void btnEditprofile_Click(object sender, EventArgs e)
    {
        txtFastName.Enabled = true;
        txtLastName.Enabled = true;
        txtDateofBirth.Enabled = true;
//        txtEmail.Enabled = true;
        txtStreet1.Enabled = true;
        txtStreet2.Enabled = true;
        txtPincode.Enabled = true;
        txtContactnumber.Enabled = true;
        drpBloodGroup.Enabled = true;
      //  txtCity.Enabled = true;
        drpCity.Enabled = true;
        drpState.Enabled = true;
        drpCountry.Enabled = true;
        drpGender.Enabled = true;

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        ptupdt.FirstName = txtFastName.Text;
        ptupdt.LastName = txtLastName.Text;
        ptupdt.DateOfBirth = txtDateofBirth.Text;
        ptupdt.Gender = drpGender.SelectedValue.ToString();
        ptupdt.Email = txtEmail.Text;
        ptupdt.BloodGroup = drpBloodGroup.SelectedValue.ToString();
        ptupdt.Street1 = txtStreet1.Text;
        ptupdt.Street2 = txtStreet2.Text;
        ptupdt.fkCityId = Convert.ToInt16(drpCity.SelectedValue);
        ptupdt.PinCode = Convert.ToInt64(txtPincode.Text);
        ptupdt.fkStateId = Convert.ToInt16(drpState.SelectedValue);
        ptupdt.fkCountryId = Convert.ToInt16(drpCountry.SelectedValue);
        ptupdt.ContactNumber = Convert.ToInt64(txtContactnumber.Text);
        ptupdt.SpecificDetail = null;

        //   ptupdt.fkRegistrationId = (Convert.ToInt16(Session["RegistrationId"]));

        //ptupdt.updt();
        ptupdt.updt(Convert.ToInt16(Session["RegistrationId"]));

    //   ptupdt.fkRegistrationId = (Convert.ToInt16(Session["RegistrationId"]));

       

    }
    protected void drpState_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpCity.Items.Clear();
        drpCity.Items.Add("--Select City--");
        l2.pkStateId = Convert.ToInt32(drpState.SelectedValue);
        drpCity.DataSource = l2.CityLogic(Convert.ToInt32(drpState.SelectedValue));
        drpCity.DataTextField = "City";
        drpCity.DataValueField = "pkCityId";
        drpCity.DataBind();

    }

    protected void btnChangepwd_Click(object sender, EventArgs e)
    {
        txtFastName.Text = Session["fname"].ToString();
        txtEmail.Text = Session["email"].ToString();
        string pwd = Session["Password"].ToString();
        Response.Redirect("ChangepasswordPat.aspx");
    }
}