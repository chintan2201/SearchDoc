﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Globalization;
using BusinessLogic;
using DataAccess;

public partial class Application_Layer_Searching_patient : System.Web.UI.Page
{

    SearchLogic l = new SearchLogic();
    SearchDataAccess d = new SearchDataAccess();
    logicDropdown l2 = new logicDropdown();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["RegistrationId"] == null)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect(URL.home);
        }
        else
        {
            
            if (!IsPostBack)
            {


                drpSpeciality.DataSource = l2.specialityLogic();
                drpSpeciality.DataTextField = "Speciality";
                drpSpeciality.DataValueField = "pkSpecialityId";
                drpSpeciality.DataBind();

                drpState.DataSource = l2.StateLogic();
                drpState.DataTextField = "State";
                drpState.DataValueField = "pkStateId";
                drpState.DataBind();

                drpHospital.DataSource = l2.HospitalLogic();
                drpHospital.DataTextField = "Hospital_Name";
                drpHospital.DataValueField = "pkHospitalId";
                drpHospital.DataBind();

                drpDoctor.DataSource = l2.DoctorLogic();
                drpDoctor.DataTextField = "First Name";
                drpDoctor.DataValueField = "pkDoctorId";
                drpDoctor.DataBind();

                //drpSpeciality.SelectedValue = Convert.ToString(Session["speciality"]);
                //drpHospital.SelectedValue = Convert.ToString(Session["hospital"]);
                //drpState.SelectedValue = Convert.ToString(Session["state"]);
                //drpCity.SelectedValue = Convert.ToString(Session["city"]);
                //drpDoctor.SelectedValue = Convert.ToString(Session["doctor"]);


                txtCity.Text = Convert.ToString(Session["city1"]);
                txtState.Text = Convert.ToString(Session["state1"]);

                l.fkSpecialityId = Convert.ToInt32(Session["speciality"]);
                l.fkHospitalId = Convert.ToInt32(Session["hospital"]);
                l.fkStateId = Convert.ToInt32(Session["state"]);
                l.FirstName = Convert.ToString(Session["doctor"]);
                l.fkCityId = Convert.ToInt32(Session["city"]);
                grdDoctorInfo.DataSource = l.SearchingDoctorLogic(l.fkSpecialityId, l.fkHospitalId, l.fkStateId, l.fkCityId, l.FirstName);
                grdDoctorInfo.DataBind();
               
            }
           

                gmap();
            
        }
    }


    public void gmap()
    {
        string fulladdress;

        fulladdress = string.Format("{0}.{1}", txtState.Text, txtCity.Text);

        string skey = ConfigurationManager.AppSettings["googlemaps.subgurim.net"];
        Subgurim.Controles.GeoCode geocode = default(Subgurim.Controles.GeoCode);

        geocode = GMap1.getGeoCodeRequest(fulladdress);
        var glatlng = new Subgurim.Controles.GLatLng(geocode.Placemark.coordinates.lat, geocode.Placemark.coordinates.lng);
        GMap1.setCenter(glatlng, 16, Subgurim.Controles.GMapType.GTypes.Normal);
        var oMarker = new Subgurim.Controles.GMarker(glatlng);
        GMap1.addGMarker(oMarker);
    }

    protected void drpState_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        drpCity.Items.Clear();
        drpCity.Items.Add("--Select City--");
        l2.pkStateId = Convert.ToInt32(drpState.SelectedValue);
        drpCity.DataSource = l2.CityLogic(Convert.ToInt32(drpState.SelectedValue));
        drpCity.DataTextField = "City";
        drpCity.DataValueField = "pkCityId";
        drpCity.DataBind();
        //drpState.Items.Clear();
        //drpState.Items.Add("--Select State--");

    }

    protected void btnFindDoctor_Click(object sender, EventArgs e)
    {
        if (drpState.SelectedValue != "0" && drpCity.SelectedValue == "--Select City--")
        {
            lblSelectCity.Visible = true;
        }
        else
        {
            lblSelectCity.Visible = false;
            txtCity.Text = drpCity.SelectedItem.ToString();
            txtState.Text = drpState.SelectedItem.ToString();

            l.fkSpecialityId = Convert.ToInt32(drpSpeciality.SelectedValue);
            l.fkHospitalId = Convert.ToInt32(drpHospital.SelectedValue);
            l.fkStateId = Convert.ToInt32(drpState.SelectedValue);
            l.FirstName = Convert.ToString(drpDoctor.SelectedItem);
            l.fkCityId = Convert.ToInt32(drpCity.SelectedValue);
            //l.fkCityId = Convert.ToInt32(drpCity.SelectedValue);
            grdDoctorInfo.DataSource = l.SearchingDoctorLogic(l.fkSpecialityId, l.fkHospitalId, l.fkStateId, l.fkCityId, l.FirstName);
            grdDoctorInfo.DataBind();

            gmap();
        }
    }

        protected void grdDoctorInfo_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "select")
        {


            Session["pkDoctorId"] = e.CommandArgument;
            int i = Convert.ToInt32(Session["pkDoctorId"]);
            LinkButton cd =  e.CommandSource as LinkButton;
            GridViewRow grv = cd.Parent.Parent as GridViewRow;
            string state = grv.Cells[6].Text;
            Session["Docstate"] = state;
            string city = grv.Cells[5].Text;
            Session["DocCity"] = city;
            Response.Redirect("AppointmentConfirm_pat.aspx");
       

        }
    }
}