﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Application_Layer_postgraduatecolleg : System.Web.UI.Page
{
    pgcollege c = new pgcollege();
    DataTable dt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


            grdPostgraduate.DataBind();
        }

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (Session["pkPgCollege"] == null)
        {
            c.Graduation_College = txtpostgraduateclg.Text;
            c.ins();
            grdPostgraduate.DataBind();
        }
        else
        {
            c.Graduation_College = txtpostgraduateclg.Text;

            int i = Convert.ToInt32(Session["pkPgCollege"]);
            c.updt(i);
            btnAdd.Text = "Add";
            grdPostgraduate.DataBind();
        }

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in grdPostgraduate.Rows)
        {
            CheckBox chk = (CheckBox)row.FindControl("chkDel");

            if (chk.Checked)
            {
                int usrid = Convert.ToInt32(grdPostgraduate.DataKeys[row.RowIndex].Value);
                c.delcit(usrid);

            }

        }
        grdPostgraduate.DataBind();
    }
    protected void grdPostgraduate_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "select")
        {

            btnAdd.Text = "UPDATE";
            Session["pkPgCollege"] = e.CommandArgument;
            int i = Convert.ToInt32(Session["pkPgCollege"]);
            dt = c.fetch(i);

            txtpostgraduateclg.Text = dt.Rows[0]["PG_College"].ToString();


        }
    }
}