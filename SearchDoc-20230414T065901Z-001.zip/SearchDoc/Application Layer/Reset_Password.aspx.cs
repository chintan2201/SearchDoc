﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using DataAccess;

public partial class Application_Layer_Reset_Password : System.Web.UI.Page
{

    ResetPasswordLogic l = new ResetPasswordLogic();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        l.Email = txtEmail.Text;
        l.Password = txtNewPassword.Text;
        l.NewPasswordLogic(txtEmail.Text,txtNewPassword.Text);
        lblDone.Visible = true;
    }
}