﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;
using BusinessLogic;
using System.Collections.Generic;

public partial class Application_Layer_Clinic_dr : System.Web.UI.Page
{
    Drp_Fill_bl drp = new Drp_Fill_bl();
    clinic_bl sl = new clinic_bl();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["RegistrationId"] == null)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect(URL.home);
        }
        if (!IsPostBack)
        {
            drpClinicCity.DataSource = drp.city();
            drpClinicCity.DataTextField = "City";
            drpClinicCity.DataValueField = "pkCityId";
            drpClinicCity.DataBind();

            drpClinicState.DataSource = drp.state();
            drpClinicState.DataTextField = "State";
            drpClinicState.DataValueField = "pkStateId";
            drpClinicState.DataBind();
        }

       
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        sl.Name= txtClinicName.Text;
        sl.Address = txtStreetName.Text;
        sl.Area = txtClinicArea.Text;
        sl.fkCityID = Convert.ToInt16(drpClinicCity.SelectedValue);
        sl.fkStateID =Convert.ToInt16(drpClinicState.SelectedValue);
        sl.ins();
        lblSuccess.Visible = true;
    }
}