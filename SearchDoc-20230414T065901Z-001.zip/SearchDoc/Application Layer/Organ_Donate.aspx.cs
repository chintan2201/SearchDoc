﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using BusinessLogic;
using DataAccess;

public partial class Application_Layer_Organ_Donate : System.Web.UI.Page
{

    organ_pro_bl orgnprobl = new organ_pro_bl();
    orgn_updt_bl orgnupdt = new orgn_updt_bl();
    orgndrp orgn = new orgndrp();
    logicDropdown l2 = new logicDropdown();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["RegistrationId"] == null)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect(URL.home);
        }
        if (!IsPostBack)
        {


            drpState.DataSource = l2.StateLogic();
            drpState.DataTextField = "State";
            drpState.DataValueField = "pkStateId";
            drpState.DataBind();

            drprelation.DataSource = orgn.relation();
            drprelation.DataTextField = "Relation";
            drprelation.DataValueField = "pkRelationID";
            drprelation.DataBind();

            drporgntype.DataSource = orgn.organtype();
            drporgntype.DataTextField = "Organtype";
            drporgntype.DataValueField = "pkOrganTypeID";
            drporgntype.DataBind();
        
        }
            if (!IsPostBack)
            {
                txtFastName.Enabled = true;
                txtLastName.Enabled = false;
                txtDateofBirth.Enabled = false;
                txtEmail.Enabled = false;
                txtStreet1.Enabled = false;
                txtStreet2.Enabled = false;
                txtPincode.Enabled = false;
                txtContactnumber.Enabled = false;
                drpBloodGroup.Enabled = false;
                drpCity.Enabled = false;
                drpState.Enabled = false;
                drpCountry.Enabled = false;
                drpGender.Enabled = false;
                txtcntcmob.Enabled = false;
                txtcntctmail.Enabled = false;
                txtcntctprsn.Enabled = false;
                drprelation.Enabled = false;
                drporgntype.Enabled = false;

                orgnprobl.display(Convert.ToInt16(Session["RegistrationId"]));

                txtFastName.Text = Session["fname"].ToString();
                txtLastName.Text = Session["lname"].ToString();
                txtDateofBirth.Text = Session["dob"].ToString();
                drpGender.SelectedValue = Session["gen"].ToString();
                txtEmail.Text = Session["email"].ToString();
                drpBloodGroup.SelectedValue = Session["bg"].ToString();
                txtStreet1.Text = Session["Add1"].ToString();
                txtStreet2.Text = Session["Add2"].ToString();
                drpCity.SelectedIndex = Convert.ToInt16(Session["city"]);
                txtPincode.Text = Session["pin"].ToString();
                drpState.SelectedIndex = Convert.ToInt16(Session["state"]);
                drpCountry.SelectedIndex = Convert.ToInt16(Session["country"]);
                txtContactnumber.Text = Session["mb"].ToString();
                txtcntctprsn.Text = Session["cntctprsn"].ToString();
                txtcntctmail.Text = Session["cntctmail"].ToString();
                txtcntcmob.Text = Session["cntctmob"].ToString();
                drprelation.SelectedIndex = Convert.ToInt32(Session["drprltn"]);
                drporgntype.SelectedIndex = Convert.ToInt32(Session["drporgntype"]);

                lblPatName.Text = Session["fname"].ToString();




             
            }
        }
    
    protected void btnEditprofile_Click(object sender, EventArgs e)
    {
        txtFastName.Enabled = true;
        txtLastName.Enabled = true;
        txtDateofBirth.Enabled = true;
        txtStreet1.Enabled = true;
        txtStreet2.Enabled = true;
        txtPincode.Enabled = true;
        txtContactnumber.Enabled = true;
        drpBloodGroup.Enabled = true;
        drpCity.Enabled = true;
        drpState.Enabled = true;
        drpCountry.Enabled = true;
        drpGender.Enabled = true;
        txtcntcmob.Enabled = true;
        txtcntctprsn.Enabled = true;
        txtcntctmail.Enabled = true;
        drprelation.Enabled = true;
        drporgntype.Enabled = true;
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        orgnupdt.FirstName = txtFastName.Text;
        orgnupdt.LastName = txtLastName.Text;
        orgnupdt.DateOfBirth = txtDateofBirth.Text;
        orgnupdt.Gender = drpGender.SelectedValue.ToString();
        orgnupdt.Email = txtEmail.Text;
        orgnupdt.BloodGroup = drpBloodGroup.SelectedValue.ToString();
        orgnupdt.Street1 = txtStreet1.Text;
        orgnupdt.Street2 = txtStreet2.Text;
        orgnupdt.fkCityId = Convert.ToInt16(drpCity.SelectedValue);
        orgnupdt.PinCode = Convert.ToInt64(txtPincode.Text);
        orgnupdt.fkStateId = Convert.ToInt16(drpState.SelectedValue);
        orgnupdt.fkCountryId = Convert.ToInt16(drpCountry.SelectedValue);
        orgnupdt.ContactNumber = Convert.ToInt64(txtContactnumber.Text);
        orgnupdt.ContactPersonName = txtcntctprsn.Text;
        orgnupdt.ContactPersonMobile = Convert.ToInt64(txtcntcmob.Text);
        orgnupdt.ContactPersonEmail = txtcntctmail.Text;
        orgnupdt.fkRelationID = Convert.ToInt16(drprelation.SelectedValue);
        orgnupdt.fkOrganTypeID = Convert.ToInt16(drporgntype.SelectedValue);

         orgnupdt.update(Convert.ToInt16(Session["RegistrationId"]));
    }
    protected void orgnbtnchngepwd_Click(object sender, EventArgs e)
    {
        txtFastName.Text = Session["fname"].ToString();
        txtEmail.Text = Session["email"].ToString();
        string pwd = Session["Password"].ToString();
        Response.Redirect("orgnChangepwd.aspx");
    }
    protected void drpState_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpCity.Items.Clear();
        drpCity.Items.Add("--Select City--");
        l2.pkStateId = Convert.ToInt32(drpState.SelectedValue);
        drpCity.DataSource = l2.CityLogic(Convert.ToInt32(drpState.SelectedValue));
        drpCity.DataTextField = "City";
        drpCity.DataValueField = "pkCityId";
        drpCity.DataBind();

    }

}