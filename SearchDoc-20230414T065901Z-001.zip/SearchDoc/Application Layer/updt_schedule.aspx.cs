﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Application_Layer_updt_schedule : System.Web.UI.Page
{
    schedule_bl c = new schedule_bl();
    DataTable dt = new DataTable();
    Drp_Fill_bl d = new Drp_Fill_bl();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            drpcity.DataSource = d.city();
            drpcity.DataTextField = "City";
            drpcity.DataValueField = "pkCityId";
            drpcity.DataBind();

            drpState.DataSource = d.state();
            drpState.DataTextField = "State";
            drpState.DataValueField = "pkStateId";
            drpState.DataBind();

            drpAddPlace.DataSource = d.hospital();
            drpAddPlace.DataTextField = "Hospital_Name";
            drpAddPlace.DataValueField = "pkHospitalId";
            drpAddPlace.DataBind();

            grdupdtschedule.DataBind();
        }
    }
    
    protected void grdupdtschedule_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "select")
        {

         
            Session["pkScheduleId"] = e.CommandArgument;
            int i = Convert.ToInt32(Session["pkScheduleId"]);
            dt = c.fetch(i);


            drpAddPlace.SelectedValue = dt.Rows[0]["fkHospitalId"].ToString();
            drpcity.SelectedValue = dt.Rows[0]["fkCityId"].ToString();
            drpState.SelectedValue = dt.Rows[0]["fkStateId"].ToString();
            drpTo.SelectedValue = dt.Rows[0]["ToTime"].ToString();
            drpFrom.SelectedValue = dt.Rows[0]["FromTime"].ToString();
            drpDay.SelectedValue = dt.Rows[0]["fkDayId"].ToString();

            //drpAddPlace.SelectedValue =grdupdtschedule.SelectedRow.Cells[2].Text;
            //drpcity.SelectedValue = grdupdtschedule.SelectedRow.Cells[6].Text.ToString();
            //drpState.SelectedValue = grdupdtschedule.SelectedRow.Cells[7].Text.ToString();
            //drpTo.SelectedValue = grdupdtschedule.SelectedRow.Cells[4].Text.ToString();
            //drpFrom.SelectedValue = grdupdtschedule.SelectedRow.Cells[3].Text.ToString();
            //drpDay.SelectedValue = grdupdtschedule.SelectedRow.Cells[5].Text.ToString();



            //txtaddcity.Text = dt.Rows[0]["City"].ToString();
            //drpstate.SelectedValue = dt.Rows[0]["fkStateID"].ToString();

        }
    }
    protected void btnAddPlace_Click(object sender, EventArgs e)
    {
        c.fkCityId = Convert.ToInt16(drpcity.SelectedValue);
        c.fkDayId = Convert.ToInt16(drpDay.SelectedValue);
        c.fkStateId = Convert.ToInt16(drpState.SelectedValue);
        c.FromTime = Convert.ToInt16(drpFrom.SelectedValue);
        c.ToTime = Convert.ToInt16(drpTo.SelectedValue);
        c.fkhospitalId = Convert.ToInt16(drpAddPlace.SelectedValue);
        c.fkRegistrationId = Convert.ToInt16(Session["RegistrationId"]);

        //c.fkStateID = Convert.ToInt16(drpstate.SelectedValue);
        int i = Convert.ToInt32(Session["pkScheduleId"]);
        c.updtSchedule(i);
        grdupdtschedule.DataBind();
    }
    protected void btndel_Click(object sender, EventArgs e)
    {

        foreach (GridViewRow row in grdupdtschedule.Rows)
        {
            CheckBox chk = (CheckBox)row.FindControl("chkDel");

            if (chk.Checked)
            {

               int usrid = Convert.ToInt32(grdupdtschedule.DataKeys[row.RowIndex].Value);
               //int usrid = Convert.ToInt16(grdupdtschedule.SelectedRow.Cells[2].Text);
               // int usrid = Convert.ToInt32(dt.PrimaryKey);//["pkScheduleId"].ToString());
                c.delschedule(usrid);

            }

        }

        grdupdtschedule.DataBind();
    }
}