﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Application_Layer_Administrator : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    Drp_Fill_bl drp = new Drp_Fill_bl();
    clinic_bl c = new clinic_bl();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["RegistrationId"] == null)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect(URL.home);
        }
        else
        {
            if (!IsPostBack)
            {
                drpState.DataSource = drp.state();
                drpState.DataTextField = "State";
                drpState.DataValueField = "pkStateId";
                drpState.DataBind();

                drpCity.DataSource = drp.city();
                drpCity.DataTextField = "City";
                drpCity.DataValueField = "pkCityId";
                drpCity.DataBind();


                grdadminhospital.DataBind();
            }
        }
    }
    protected void btnInsertHospital_Click(object sender, EventArgs e)
    {
        if (Session["pkHospitalId"] == null)
        {
            c.Name = txtHospital.Text;
            c.Address = txtHospitalAddress.Text;
            c.Area = txtarea.Text;
            c.fkCityID = Convert.ToInt16(drpCity.SelectedValue);
            c.fkStateID = Convert.ToInt16(drpState.SelectedValue);
            c.ins();
            grdadminhospital.DataBind();
        }
        else
        {
            c.Name = txtHospital.Text;
            c.Address = txtHospitalAddress.Text;
            c.Area = txtarea.Text;
            c.fkCityID = Convert.ToInt16(drpCity.SelectedValue);
            c.fkStateID = Convert.ToInt16(drpState.SelectedValue);
            int i = Convert.ToInt32(Session["pkHospitalId"]);
            c.updt(i);
            btnInsertHospital.Text = "Add";
            grdadminhospital.DataBind();
        }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in grdadminhospital.Rows)
        {
            CheckBox chk = (CheckBox)row.FindControl("chkDel");

            if (chk.Checked)
            {
                int usrid = Convert.ToInt32(grdadminhospital.DataKeys[row.RowIndex].Value);
                c.delcit(usrid);

            }

        }
        grdadminhospital.DataBind();
    }
    protected void grdadminhospital_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    protected void grdadminhospital_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "select")
        {

            btnInsertHospital.Text = "UPDATE";
            //GridViewRow grdSelRow = grdSpecialism.SelectedRow;
            //LinkButton link = (LinkButton)grdSpecialism.Rows[0].FindControl("link");
            Session["pkHospitalId"] = e.CommandArgument;
            int i = Convert.ToInt32(Session["pkHospitalId"]);
            dt = c.fetch(i);

            txtarea.Text = dt.Rows[0]["Area"].ToString();
            txtHospital.Text = dt.Rows[0]["Hospital_Name"].ToString();
            txtHospitalAddress.Text = dt.Rows[0]["Street_Name"].ToString();
            drpCity.SelectedValue = dt.Rows[0]["fkCityId"].ToString();
            drpState.SelectedValue = dt.Rows[0]["fkStateId"].ToString();
        }

    }
}