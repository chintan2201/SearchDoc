﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Application_Layer_CityState : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    Drp_Fill_bl drp = new Drp_Fill_bl();
    City c = new City();

    protected void Page_Load(object sender, EventArgs e)
    { if (!IsPostBack)
        {
            Session["pkCityId"] = null;
            drpState.DataSource = drp.state();
            drpState.DataTextField = "State";
            drpState.DataValueField = "pkStateId";
            drpState.DataBind();

            grdadmincity.DataBind();

        }

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (Session["pkCityId"] == null)
        {
            c.Cityi = txtCity.Text;
            c.fkStateID = Convert.ToInt16(drpState.SelectedValue);
            c.inscit();
            grdadmincity.DataBind();
        }
        else
        {
            c.Cityi = txtCity.Text;
            c.fkStateID = Convert.ToInt16(drpState.SelectedValue); 
            int i = Convert.ToInt32(Session["pkCityId"]);
            c.updtcit(i);
            btnAdd.Text = "Add";
            grdadmincity.DataBind();
        }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

        foreach (GridViewRow row in grdadmincity.Rows)
        {
            CheckBox chk = (CheckBox)row.FindControl("chkDel");

            if (chk.Checked)
            {
                int usrid = Convert.ToInt32(grdadmincity.DataKeys[row.RowIndex].Value);
                c.delcit(usrid);

            }

        }
        grdadmincity.DataBind();
    }
    protected void grdadmincity_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "select")
        {

            btnAdd.Text = "Update";
            Session["pkCityId"] = e.CommandArgument;
            int i = Convert.ToInt32(Session["pkCityId"]);
            dt = c.fetch(i);

            txtCity.Text = dt.Rows[0]["City"].ToString();
            drpState.SelectedValue = dt.Rows[0]["fkStateId"].ToString();
            
        }
    }
}