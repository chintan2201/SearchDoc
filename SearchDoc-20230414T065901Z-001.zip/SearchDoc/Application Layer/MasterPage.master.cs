﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_Layer_MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnCreateschedule_Click(object sender, EventArgs e)
    {
        Response.Redirect(URL.create_schedule);
       // Response.Redirect("schedule.aspx");
    }
    protected void btnUpdateschedule_Click(object sender, EventArgs e)
    {
        Response.Redirect(URL.update_Schedule);
    }
    protected void btnTakeappointment_Click(object sender, EventArgs e)
    {
        Response.Redirect(URL.Searching1);
    }
    protected void btnOrganDonate_Click(object sender, EventArgs e)
    {
        Response.Redirect(URL.organDonate_Doc);
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
       
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            Response.Redirect(URL.home);
     
    }
    protected void btnProfile_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dr.aspx");
    }
}
