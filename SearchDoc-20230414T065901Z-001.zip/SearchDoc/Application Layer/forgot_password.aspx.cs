﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

public partial class Application_Layer_forgot_password : System.Web.UI.Page
{
    Drp_Fill_bl obj = new Drp_Fill_bl();
    forgot_pwd_bl pw = new forgot_pwd_bl();
    protected void Page_Load(object sender, EventArgs e)
    {
        drpque.DataSource = obj.que();
        drpque.DataTextField = "Que";
        drpque.DataValueField = "pkQueId";
        drpque.DataBind();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        pw.fkQueId = Convert.ToInt16(drpque.SelectedValue);
        pw.HintAns = txtans.Text.ToString();
        pw.EmailID =txtEmail.Text.ToString();
        pw.recpwd();
        lblpwd.Text = pw.recpwd().ToString();

        MailMessage msg = new MailMessage();

        msg.From = new MailAddress("searchdoc4@gmail.com");
        msg.To.Add(new MailAddress(txtEmail.Text.ToString()));

        msg.Subject = "Your Password";
        msg.Body = "Your Password is  " + lblpwd.Text;

        msg.IsBodyHtml = true;
        SmtpClient client = new SmtpClient();
        client.Host = "smtp.gmail.com";
        client.Port = 587;
        client.EnableSsl = true;
        client.Credentials = new System.Net.NetworkCredential("searchdoc4@gmail.com", "searchd0c");
        client.Send(msg);


        //System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();

        //msg.From = new MailAddress("dp7630@gmail.com");

        //msg.To.Add(txtEmail.Text);//Text Box for To Address  

        //string subject="forgot password";

        //msg.Subject = subject ; //Text Box for subject  

        //msg.IsBodyHtml = true;

        //string body = " reset  your password on given link http://localhost:1173/SearchDoc/Application%20Layer/Reset_Password.aspx";

        //msg.Body = body;//Text Box for body  

        //msg.Priority = MailPriority.High;

        //System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient("smtp.gmail.com", 587);

        //client.UseDefaultCredentials = false;

        //client.Credentials = new System.Net.NetworkCredential("", "");

        //client.Port = 587;

        //client.Host = "smtp.gmail.com";

        //client.EnableSsl = true;

        //object userstate = msg;

        //client.Send(msg);
        //lblinfo.Visible=true;
    }
}