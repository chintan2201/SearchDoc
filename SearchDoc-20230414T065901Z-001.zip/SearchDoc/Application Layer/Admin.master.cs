﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_Layer_Admin : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Administrator.aspx");
    }
    protected void btnCityState_Click(object sender, EventArgs e)
    {
        Response.Redirect("CityState.aspx");
    }

    protected void btnGraduateclg_Click(object sender, EventArgs e)
    {
        Response.Redirect("graduatecolleg.aspx");
    }
    protected void btnPostGraduateclg_Click(object sender, EventArgs e)
    {
        Response.Redirect("postgraduatecolleg.aspx");
    }
    protected void Logout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.RemoveAll();
        Session.Abandon();
        Response.Redirect(URL.home);
    }
}
