﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Application_Layer_OrganDonate_Patient : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand cmd;
    DataTable dt;
    SqlDataAdapter adp;
    orgndrp orgn = new orgndrp();
    protected void Page_Load(object sender, EventArgs e)
    {
        
 conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        conn.Open();

        if (Session["RegistrationId"] == null)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect(URL.home);
        }
        if (!IsPostBack)
        {


            drporgnrelation.DataSource = orgn.relation();
            drporgnrelation.DataTextField = "Relation";
            drporgnrelation.DataValueField = "pkRelationID";
            drporgnrelation.DataBind();

            drporgntype.DataSource = orgn.organtype();
            drporgntype.DataTextField = "Organtype";
            drporgntype.DataValueField = "pkOrganTypeID";
            drporgntype.DataBind();

        }
    }
   
    protected void btnsumbit_Click1(object sender, EventArgs e)
    {
        cmd = new SqlCommand("strporgan_reg_drpt", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@ContactPersonName", txtorgncntactprsn.Text);
        cmd.Parameters.AddWithValue("@ContactPersonMobile", txtorgncntctmobile.Text);
        cmd.Parameters.AddWithValue("@ContactPersonEmail", txtorgncntctemail.Text);
        cmd.Parameters.AddWithValue("@fkRelationID", Convert.ToInt16(drporgnrelation.SelectedValue));
        cmd.Parameters.AddWithValue("@fkOrganTypeID", Convert.ToInt16(drporgntype.SelectedValue));
        cmd.Parameters.AddWithValue("@fkRegistrationId", Convert.ToInt16(Session["RegistrationId"]));
        cmd.ExecuteNonQuery();
       
    }
}
