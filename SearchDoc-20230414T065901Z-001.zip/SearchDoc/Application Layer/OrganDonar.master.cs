﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Application_Layer_OrganDonar : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnProfile_Click(object sender, EventArgs e)
    {
        Response.Redirect("Organ_Donate.aspx");
    }
    protected void btnChangepassword_Click(object sender, EventArgs e)
    {
        Response.Redirect("Odcpwd.aspx");
    }
    protected void btnFindDoctor_Click(object sender, EventArgs e)
    {
        Response.Redirect("OdFDoctor.aspx");
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.RemoveAll();
        Session.Abandon();
        Response.Redirect(URL.home);
    }
}
