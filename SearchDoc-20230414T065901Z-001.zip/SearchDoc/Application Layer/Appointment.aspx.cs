﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using BusinessLogic;
using DataAccess;

public partial class Application_Layer_Appointment : System.Web.UI.Page
{
  
    LoginLogic l1 = new LoginLogic();
    login_data d1 = new login_data();
    protected void Page_Load(object sender, EventArgs e)
    {
      

    }

   
  



   
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        l1.UserName = txtuname.Text;
        l1.Password = txtPass.Text;
        l1.Login_l(txtuname.Text, txtPass.Text);



    }


    protected void btnCreateAccount_Click(object sender, EventArgs e)
    {
        Response.Redirect("Registration.aspx");
    }
}
   