﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Configuration;
using System.Data;
public partial class Appointmentconfirmation : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    schedule_bl s = new schedule_bl();
    protected void Page_Load(object sender, EventArgs e)
    {
        
            txtState.Text = Session["Docstate"].ToString();
            txtCity.Text = Session["DocCity"].ToString();
            int i = Convert.ToInt32(Session["pkDoctorId"]);
            Label1.Text = i.ToString();
            GridView1.DataBind();

            gmap();
       
    }

    public void gmap()
    {
        string fulladdress;

        fulladdress = string.Format("{0}.{1}", txtState.Text, txtCity.Text);

        string skey = ConfigurationManager.AppSettings["googlemaps.subgurim.net"];
        Subgurim.Controles.GeoCode geocode = default(Subgurim.Controles.GeoCode);

        geocode = GMap1.getGeoCodeRequest(fulladdress);
        var glatlng = new Subgurim.Controles.GLatLng(geocode.Placemark.coordinates.lat, geocode.Placemark.coordinates.lng);
        GMap1.setCenter(glatlng, 16, Subgurim.Controles.GMapType.GTypes.Normal);
        var oMarker = new Subgurim.Controles.GMarker(glatlng);
        GMap1.addGMarker(oMarker);
    }


    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName =="select")
        {
            
            Session["pkScheduleId"] = e.CommandArgument;
            int i = Convert.ToInt32(Session["pkScheduleId"]);
            int j = Convert.ToInt32(Session["pkDoctorId"]);
            dt = s.fetchd(i);
            Session["fkDoctorId"] = dt.Rows[0]["First Name"].ToString();
            Session["fkDayId"] = dt.Rows[0]["Day"].ToString();
            Session["FromTime"] = dt.Rows[0]["FromTime"].ToString();
            Session["ToTime"] = dt.Rows[0]["ToTime"].ToString();
            Session["photo"] = dt.Rows[0]["photo"].ToString();
            //Session["fkDoctorId"] = dt.Rows[0]["fkDoctorId"].ToString();
            Session["fkHospitalId"] = dt.Rows[0]["Hospital_Name"].ToString();
            Session["HospID"] = dt.Rows[0]["fkHospitalId"].ToString();
           // Session["fkRegistrationId"] = dt.Rows[0]["fkRegistrationId"].ToString();
            //Session["fkCityId"] = dt.Rows[0]["fkCityId"].ToString();
            //Session["fkStateId"] = dt.Rows[0]["fkStateId"].ToString();
            //string a = Session["fkDoctorId"].ToString();
            Response.Redirect("Appointment.aspx");
        }

    }
   
}