﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SmsClient;
using System.Net.Mail;
public partial class Application_Layer_TakeAppointment : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataAdapter adp;
    DataTable dt;
    SqlDataReader dr=null;
    DataSet ds;
    Random r = new Random();
    int pw;
    Int64 i;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        conn.Open();
        lblWhen1.Text = Session["fkDayId"].ToString();
        lblWhen2.Text = Session["ToTime"].ToString();
        lblWhen3.Text = Session["FromTime"].ToString();
        lblWho1.Text = Session["fkDoctorId"].ToString();
        lblWhere1.Text = Session["fkHospitalId"].ToString();
        imgDoctor.ImageUrl = Session["photo"].ToString();

        int iii = Convert.ToInt16(Session["pkDoctorId"]);
        int jjj = Convert.ToInt16(Session["pkScheduleId"]);
    }
    protected void btnAppointment_Click(object sender, EventArgs e)
    {
       
        if (Session["act"].ToString()== txtcode.Text.ToString())
        {
            cmd = new SqlCommand("strp_disp_Count", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            int iii = Convert.ToInt16(Session["pkDoctorId"]);
            int jjj = Convert.ToInt16(Session["pkScheduleId"]);


            cmd.Parameters.AddWithValue("@fkDoctorId", iii);
            cmd.Parameters.AddWithValue("@fkScheduleId", jjj);

            // adp = new SqlDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            // //ds.Clear();
            //// ds.Reset();
            // adp.Fill(ds);
            //  p = Convert.ToInt16(ds.Tables[0].Rows[0].ItemArray[0].ToString());
            //    // conn.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            if (dr.HasRows == true)
            {

                // Convert.ToInt32(dr.HasRows());
                //string pll = dr["CountApt"].ToString();
                pw = Convert.ToInt16((dr["CountApt"]).ToString());
            }
            conn.Close();


            if (pw < 25)
            {
                cmd = new SqlCommand("strp_ins_takeapp", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@fkDrId", iii);
                cmd.Parameters.AddWithValue("@fkHospitalId", Convert.ToInt16(Session["HospId"]));
                cmd.Parameters.AddWithValue("@fkScheduleId", jjj);
                //cmd.Parameters.AddWithValue("@fkRegId",Convert.ToInt16(Session["RegistrationId"]));
                cmd.Parameters.AddWithValue("@fkRegId", 21);
                pw = pw + 1;
                cmd.Parameters.AddWithValue("@CountApt", pw);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                SendSms sms = new SendSms();
                string status = sms.send("8866136291", "dhlovesall", "Your Appointment is fixed on " + lblWhen1.Text + " from " + lblWhen3.Text + " to " + lblWhen2.Text + " with Dr." + lblWho1.Text + " at " + lblWhere1.Text + "...", txtphno.Text);
                if (status == "1")
                {
                    Label2.Text = "Appointment has been fixed successfully";
                }
                else if (status == "2")
                {
                    Label2.Text = "Internet connection is not open";
                }
                else
                {
                    Label2.Text = "Invalid";
                }

                MailMessage msg = new MailMessage();

                msg.From = new MailAddress("searchdoc4@gmail.com");
                msg.To.Add(new MailAddress(txtemail.Text.ToString()));

                msg.Subject = "Appointment Confirmation";
                msg.Body = "Your Appointment is fixed on   " + lblWhen1.Text + " from " + lblWhen3.Text + " to " + lblWhen2.Text + " with Dr." + lblWho1.Text + " at " + lblWhere1.Text;

                msg.IsBodyHtml = true;
                SmtpClient client = new SmtpClient();
                client.Host = "smtp.gmail.com";
                client.Port = 587;
                client.EnableSsl = true;
                client.Credentials = new System.Net.NetworkCredential("searchdoc4@gmail.com", "searchd0c");
                client.Send(msg);


            }
            else
            {
             //   btnAppointment.Attributes.Add("OnClick", "return aMessage");
                Label2.Text = "Appointment is not available for this time period,please try again later";
            }
  

        }
        else
        {
            Label1.Text = "Wrong Code";

        }
       
    }
     
    protected void btnno_Click(object sender, EventArgs e)
    {

        
        i = r.Next(123456,654321);
        SendSms sms = new SendSms();
        string status = sms.send("8866136291", "dhlovesall", "Your Activation Code is " + i + "", txtphno.Text);
        if (status == "1")
        {
            
            Label1.Text = "Activation Code Has Been Send On Your Mobile";

        }
        else if (status == "2")
        {
            Label1.Text = "Internet connection is not open";
        }
        else
        {
            Label1.Text = "Invalid";
        }

        

        Session["act"] = i.ToString();
    }
}