﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

namespace DataAccess
{
    /// <summary>
    /// Summary description for SubmitScheduleDataAccess
    /// </summary>
    public class SubmitScheduleDataAccess
    {
        SqlConnection conn;
        SqlCommand cmd;
        DataTable dt = new DataTable();
        SqlDataAdapter adp;
        public SubmitScheduleDataAccess()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        }

        #region Submit Data
        /// <summary>
        /// Submit DataAccess
        /// </summary>
        /// <param name="Day"></param>
        /// <param name="FromTime"></param>
        /// <param name="ToTime"></param>
        /// <param name="Place"></param>
        /// <returns></returns>
        public int SubmitDataAccess(int Day, int FromTime, int ToTime, string Place)
        {
            cmd = new SqlCommand("SubmitSchedule", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Day", Day);
            cmd.Parameters.AddWithValue("@FromTime", FromTime);
            cmd.Parameters.AddWithValue("@ToTime", ToTime);
            cmd.Parameters.AddWithValue("@Place", Place);
            int i;
            try
            {
                conn.Open();
                i = cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                return 0;
            }
            finally
            {
                conn.Close();
            }
            return i;
        }
        #endregion
    }
}