﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;
/// <summary>
/// Summary description for forgot__pwd_dl
/// </summary>
public class forgot__pwd_dl
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataReader dr;
        
	public forgot__pwd_dl()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
	}

    public string recover(string EmailID, int fkQueId, string HintAns)
    {
        string pw;

        cmd = new SqlCommand("str_pwd_recover", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Email", EmailID);
        cmd.Parameters.AddWithValue("@fkqueid", fkQueId);
        cmd.Parameters.AddWithValue("@ans", HintAns);
        conn.Open();
        dr = cmd.ExecuteReader();
        dr.Read();

        dr.HasRows.ToString();

        pw = dr["Password"].ToString();
        conn.Close();
        return pw;

    }
    

}