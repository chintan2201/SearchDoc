﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

namespace DataAccess
{
    /// <summary>
    /// Summary description for DropdownDataAccess
    /// </summary>
    public class DropdownDataAccess
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        public DropdownDataAccess()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        }


        public DataTable specialityData()
        {
            cmd = new SqlCommand("select * from tbl_Speciality", conn);
            adp = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adp.Fill(dt);
            return dt;
        }

        public DataTable StateData()
        {

            cmd = new SqlCommand("select * from tbl_State", conn);
            adp = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adp.Fill(dt);
            return dt;
        }

        public DataTable CityData(int pkStateId)
        {
            cmd = new SqlCommand("select * from tbl_City where fkStateId=@pkStateId", conn);
            cmd.Parameters.AddWithValue("@pkStateId", pkStateId);
            adp = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adp.Fill(dt);
            return dt;
        }

        public DataTable HospitalData()
        {
            cmd = new SqlCommand("select * from tbl_Hospital", conn);
            adp = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adp.Fill(dt);
            return dt;
        }

        public DataTable DoctorData()
        {
            cmd = new SqlCommand("select * from tbl_Doctor", conn);
            adp = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adp.Fill(dt);
            return dt;
        }
    }
}