﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

/// <summary>
/// Summary description for Drp_Fill_da
/// </summary>
public class Drp_Fill_da
{
    SqlConnection conn;
    SqlCommand cmd;
    DataTable dt;
    SqlDataAdapter adp;

	public Drp_Fill_da()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        conn.Open();
    }

    public DataTable quefun()
    {
        cmd = new SqlCommand("strp_que", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }

    public DataTable gradclg()
    {
        cmd = new SqlCommand("strp_gradclg", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }


    public DataTable pgclg()
    {
        cmd = new SqlCommand("strp_pgclg", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }

    public DataTable spec()
    {
        cmd = new SqlCommand("strp_spec", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }

    public DataTable city()
    {
        cmd = new SqlCommand("strp_city", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }

    public DataTable state()
    {
        cmd = new SqlCommand("strp_state", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }

    public DataTable hos()
    {
        cmd = new SqlCommand("strp_hospital", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }

}