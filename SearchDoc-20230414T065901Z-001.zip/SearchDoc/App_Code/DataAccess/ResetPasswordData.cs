﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

namespace DataAccess
{
    /// <summary>
    /// Summary description for ResetPasswordData
    /// </summary>
    public class ResetPasswordData
    {

        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataSet ds;
        public ResetPasswordData()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        }

        public int NewPasswordData(string Email, string Password)
        {
            cmd = new SqlCommand("StoredProcedure1", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Email", Email);
            cmd.Parameters.AddWithValue("@Password", Password);
            int i = 1;
            try
            {
                conn.Open();
                return i = cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                return 0;
            }
            finally
            {
                conn.Close();
            }

            return i;
        }
    }
}