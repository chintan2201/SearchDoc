﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

namespace DataAccess
{
    /// <summary>
    /// Summary description for login_data
    /// </summary>
    public class login_data
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataSet ds;

        public login_data()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        }

        #region Login Method
        /// <summary>
        /// Login Method
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        public void Login_d(string UserName, string Password)
        {
            string str = "Login";
            cmd = new SqlCommand(str, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserName", UserName);
            cmd.Parameters.AddWithValue("@Password", Password);
            conn.Open();
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                HttpContext.Current.Session["RegistrationId"] = dr["pkRegistrationId"].ToString();
                HttpContext.Current.Session["login"] = dr["UserName"].ToString();
                HttpContext.Current.Session["Password"] = dr["Password"].ToString();

                if (Convert.ToInt32(dr["fkUserTypeId"]) == 1)
                {
                    HttpContext.Current.Response.Redirect(URL.patient);
                }
                else if (Convert.ToInt32(dr["fkUserTypeId"]) == 2)
                {
                    HttpContext.Current.Response.Redirect(URL.doctor);
                }
                else if (Convert.ToInt32(dr["fkUserTypeId"]) == 3)
                {
                    HttpContext.Current.Response.Redirect("Administrator.aspx");
                }
                else if (Convert.ToInt32(dr["fkUserTypeId"]) == 4)
                {
                    HttpContext.Current.Response.Redirect(URL.organdonator);
                }
            }
            else
            {

            }
        }

        #endregion

        public void EmailCheckData(string Email)
        {
            string str = "strp_EmailCheck";
            cmd = new SqlCommand(str, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Email", Email);

            conn.Open();
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                HttpContext.Current.Session["EmailCheck"] = dr["Email"].ToString();


            }
        }
    }
}