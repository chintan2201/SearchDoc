﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
/// <summary>
/// Summary description for Organregistration
/// </summary>
public class Organregistration
{
    SqlConnection conn;
    SqlCommand cmd;
    DataTable dt;
    SqlDataAdapter adp;
    public Organregistration()
    {
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
    }
    public int intorgnregdb(string UserName, int fkUserTypeId, string FirstName, string LastName, string DateOfBirth, string Gender, string BloodGroup, string Email, string Password, int fkqueid, string ans, string Street1, string Street2, int fkCityId, int fkCountryId, int fkStateId, Int32 PinCode, Int64 ContactNumber, string ContactPersonName, Int64 ContactPersonMobile, string ContactPersonEmail, int fkRelationID, int fkOrganTypeID)
    {
        cmd = new SqlCommand("strporganreg", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserName", UserName);
        cmd.Parameters.AddWithValue("@fkUserTypeId", fkUserTypeId);
        cmd.Parameters.AddWithValue("@FirstName", FirstName);
        cmd.Parameters.AddWithValue("@LastName", LastName);
        cmd.Parameters.AddWithValue("@DateOfBirth", DateOfBirth);
        cmd.Parameters.AddWithValue("@Gender", Gender);
        cmd.Parameters.AddWithValue("@BloodGroup", BloodGroup);
        cmd.Parameters.AddWithValue("@Email", Email);
        cmd.Parameters.AddWithValue("@Password", Password);
        cmd.Parameters.AddWithValue("@Question", fkqueid);
        cmd.Parameters.AddWithValue("@ans", ans);
        cmd.Parameters.AddWithValue("@Street1", Street1);
        cmd.Parameters.AddWithValue("@Street2", Street2);
        cmd.Parameters.AddWithValue("@fkCityId", fkCityId);
        cmd.Parameters.AddWithValue("@fkCountryId", fkCountryId);
        cmd.Parameters.AddWithValue("@fkStateId", fkStateId);
        cmd.Parameters.AddWithValue("@PinCode", PinCode);
        cmd.Parameters.AddWithValue("@ContactNumber", ContactNumber);
        cmd.Parameters.AddWithValue("@ContactPersonName", ContactPersonName);
        cmd.Parameters.AddWithValue("@ContactPersonMobile", ContactPersonMobile);
        cmd.Parameters.AddWithValue("@ContactPersonEmail", ContactPersonEmail);
        cmd.Parameters.AddWithValue("@fkRelationID", fkRelationID);
        cmd.Parameters.AddWithValue("@fkOrganTypeID", fkOrganTypeID);
        //  cmd.Parameters.AddWithValue("fkRegistrationId", fkRegistrationId);
        int i;

        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;

    }
}