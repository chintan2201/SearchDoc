﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for orgndrpdb
/// </summary>
public class orgndrpdb
{
    SqlConnection conn;
    SqlCommand cmd;
    DataTable dt;
    SqlDataAdapter adp;
	public orgndrpdb()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        conn.Open();
	}
    
    public DataTable relationdb()
    {
        cmd = new SqlCommand("strporgnrelation", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }
    public DataTable organtypedb()
    {
        cmd = new SqlCommand("strporgntype", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }
}