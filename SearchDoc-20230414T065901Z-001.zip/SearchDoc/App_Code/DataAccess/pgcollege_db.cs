﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for pgcollege_db
/// </summary>
public class pgcollege_db
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataAdapter adp;
    DataTable dt;
	
	public pgcollege_db()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString); 
	}
    public int ins(string graduateclg)
    {
        cmd = new SqlCommand("strpins_pgraduate", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@PG_College", graduateclg);


        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public int updt(int pkGraduationCollege, string graduateclg)
    {
        cmd = new SqlCommand("strpupdt_pgraduate", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkPgCollege", pkGraduationCollege);
        cmd.Parameters.AddWithValue("@PG_College", graduateclg);

        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public int del(int pkGraduationCollege)
    {
        cmd = new SqlCommand("strpdel_pgraduate", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkPgCollege", pkGraduationCollege);

        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public DataTable fetc(int pkGraduationCollege)
    {

        cmd = new SqlCommand("Strppgraduate_fetch", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkPgCollege", pkGraduationCollege);
        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }


}