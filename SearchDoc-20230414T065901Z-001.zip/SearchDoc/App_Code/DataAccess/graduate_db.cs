﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public class graduate_db
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataAdapter adp;
    DataTable dt;
	public graduate_db()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString); 
	}

    public int insgraduate(string graduateclg)
    {
        cmd = new SqlCommand("strpins_graduate", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@Graduation_College",graduateclg);
        

        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public int updt(int pkGraduationCollege, string graduateclg)
    {
        cmd = new SqlCommand("strpupdt_graduate", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkGraduationCollege", pkGraduationCollege);
        cmd.Parameters.AddWithValue("@Graduation_College", graduateclg);

        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public int del(int pkGraduationCollege)
    {
        cmd = new SqlCommand("strpdel_graduate", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkGraduationCollege", pkGraduationCollege);

        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public DataTable fetc(int pkGraduationCollege)
    {

        cmd = new SqlCommand("Strpgraduate_fetch", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkGraduationCollege", pkGraduationCollege);
        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }


}