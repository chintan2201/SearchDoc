﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;
/// <summary>
/// Summary description for Patient_Updt_da
/// </summary>
public class Patient_Updt_da
{
    SqlConnection conn;
    SqlCommand cmd;
   
	public Patient_Updt_da()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
    }

    public int pt_updt(string fname, string lname, string dob, string gender, string email, string bg, string street1, string street2, int fkCityId, Int64 pin, int fkStateId, int fkCountryId, Int64 mb, string detail,int fkRegistrationId)
    {
        cmd = new SqlCommand("strp_pt_updt", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@FirstName",fname);
        cmd.Parameters.AddWithValue("@LastName", lname);
        cmd.Parameters.AddWithValue("@DateOfBirth",dob);
        cmd.Parameters.AddWithValue("@Gender",gender);
        cmd.Parameters.AddWithValue("@Email",email);
        cmd.Parameters.AddWithValue("@BloodGroup",bg);
        cmd.Parameters.AddWithValue("@Street1",street1);
        cmd.Parameters.AddWithValue("@Street2",street2);
        cmd.Parameters.AddWithValue("@fkCityId",fkCityId);
        cmd.Parameters.AddWithValue("@PinCode",pin );
        cmd.Parameters.AddWithValue("@fkStateId",fkStateId);
        cmd.Parameters.AddWithValue("@fkCountryId",fkCountryId);
        cmd.Parameters.AddWithValue("@ContactNumber",mb);
        cmd.Parameters.AddWithValue("@SpecificDetail",detail);
        cmd.Parameters.AddWithValue("@fkRegistrationId",fkRegistrationId);

        int i;


        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();

        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }
}