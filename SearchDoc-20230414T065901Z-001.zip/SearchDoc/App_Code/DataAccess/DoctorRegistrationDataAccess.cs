﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.Sql;
using System.Web.SessionState;
using BusinessLogic;


namespace DataAccess
{
    /// <summary>
    /// Summary description for DoctorRegistrationDataAccess
    /// </summary>
    public class DoctorRegistrationDataAccess
    {
        SqlConnection conn;
        SqlCommand cmd;
        public DoctorRegistrationDataAccess()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        }

        public int DoctorRegistrationData(string UserName, int fkUserTypeId, string FirstName, string LastName, int fkSpecialityId, string DateOfBirth, string Gender, string BloodGroup, string Email, string Password, int fkqueid, string ans, string Street1, string Street2, int fkCityId, int fkCountryId, int fkStateId, int PinCode, Int64 ContactNumber, string Photo, int Graduation_Year, int Graduation_College, int PG_Year, int PG_College)
        {
            cmd = new SqlCommand("DoctorRegistration", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@UserName", UserName);
            cmd.Parameters.AddWithValue("@fkUserTypeId", fkUserTypeId);
            cmd.Parameters.AddWithValue("@FirstName", FirstName);
            cmd.Parameters.AddWithValue("@LastName", LastName);
            cmd.Parameters.AddWithValue("@fkSpecialityId", fkSpecialityId);
            cmd.Parameters.AddWithValue("@DateOfBirth", DateOfBirth);
            cmd.Parameters.AddWithValue("@Gender", Gender);
            cmd.Parameters.AddWithValue("@BloodGroup", BloodGroup);
            cmd.Parameters.AddWithValue("@Email", Email);
            cmd.Parameters.AddWithValue("@Password", Password);
            cmd.Parameters.AddWithValue("@Question", fkqueid);
            cmd.Parameters.AddWithValue("@ans", ans);
            cmd.Parameters.AddWithValue("@Street1", Street1);
            cmd.Parameters.AddWithValue("@Street2", Street2);
            cmd.Parameters.AddWithValue("@fkCityId", fkCityId);
            cmd.Parameters.AddWithValue("@fkCountryId", fkCountryId);
            cmd.Parameters.AddWithValue("@fkStateId", fkStateId);
            cmd.Parameters.AddWithValue("@PinCode", PinCode);
            cmd.Parameters.AddWithValue("@ContactNumber", ContactNumber);
            cmd.Parameters.AddWithValue("@Photo", Photo);
            //cmd.Parameters.AddWithValue("@fkDoctorId",fkDoctorId);
            cmd.Parameters.AddWithValue("@Graduation_Year", Graduation_Year);
            cmd.Parameters.AddWithValue("@fkGraduationCollege", Graduation_College);
            cmd.Parameters.AddWithValue("@PG_Year", PG_Year);
            cmd.Parameters.AddWithValue("@fkPgCollege", PG_College);
            cmd.Parameters.AddWithValue("@flag", "i");


            int i;

            try
            {

                conn.Open();
                i = cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                return 0;
            }
            finally
            {
                conn.Close();

            }
            return i;
        }
    }
}