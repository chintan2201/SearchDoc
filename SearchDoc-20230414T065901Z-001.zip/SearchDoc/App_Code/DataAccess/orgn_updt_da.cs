﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

/// <summary>
/// Summary description for orgn_updt_da
/// </summary>
public class orgn_updt_da
{
    SqlCommand cmd;
    SqlConnection conn;
	public orgn_updt_da()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public int  orgn_updt(string fname, string lname, string dob, string gender, string email, string bg, string street1, string street2, int fkCityId, Int64 pin, int fkStateId, int fkCountryId, Int64 mb,string cntctprsn,Int64 cntctmob,string cntctmail,int drprltn,int drporgntype,int fkRegistrationId)
    {
        cmd = new SqlCommand("strp_orgn_updt", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@FirstName", fname);
        cmd.Parameters.AddWithValue("@LastName", lname);
        cmd.Parameters.AddWithValue("@DateOfBirth", dob);
        cmd.Parameters.AddWithValue("@Gender", gender);
        cmd.Parameters.AddWithValue("@Email", email);
        cmd.Parameters.AddWithValue("@BloodGroup", bg);
        cmd.Parameters.AddWithValue("@Street1", street1);
        cmd.Parameters.AddWithValue("@Street2", street2);
        cmd.Parameters.AddWithValue("@fkCityId", fkCityId);
        cmd.Parameters.AddWithValue("@PinCode", pin);
        cmd.Parameters.AddWithValue("@fkStateId", fkStateId);
        cmd.Parameters.AddWithValue("@fkCountryId", fkCountryId);
        cmd.Parameters.AddWithValue("@ContactNumber", mb);
        cmd.Parameters.AddWithValue("@ContactPersonName", cntctprsn);
        cmd.Parameters.AddWithValue("@ContactPersonMobile", cntctmob);
        cmd.Parameters.AddWithValue("@ContactPersonEmail", cntctmail);
        cmd.Parameters.AddWithValue("@fkRelationID", drprltn);
        cmd.Parameters.AddWithValue("@fkOrganTypeID", drporgntype);
        cmd.Parameters.AddWithValue("@fkRegistrationId", fkRegistrationId);

        int i;


        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();

        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }
}