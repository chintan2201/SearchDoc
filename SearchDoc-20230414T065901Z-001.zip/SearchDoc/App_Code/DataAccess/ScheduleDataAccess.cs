﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;
using System.Collections.Generic;



namespace DataAccess
{   /// <summary>
    /// Summary description for ScheduleDataAccess
    /// </summary>
    public class ScheduleDataAccess
    {
        SqlConnection conn;
        SqlCommand cmd;
        DataTable dt=new DataTable() ;
        SqlDataAdapter adp;
   
        
         public ScheduleDataAccess()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        }

         #region add place
         /// <summary>
        /// add place to datatable
        /// </summary>
        /// <param name="Day"></param>
        /// <param name="FromTime"></param>
        /// <param name="ToTime"></param>
        /// <param name="Place"></param>
         //public void ScheduleData(string Day, int FromTime, int ToTime, string Place, string ClinicName, string StreetName, string Area, string City, string State)
         //{
            
            
         //             DataColumn day = new DataColumn();
         //             day.DataType = typeof(string);
         //             day.ColumnName = "Day";
         //             dt.Columns.Add(day);


         //             DataColumn fromtime = new DataColumn();
         //             fromtime.DataType = typeof(int);
         //             fromtime.ColumnName = "FromTime";
         //             dt.Columns.Add(fromtime);

         //             DataColumn totime = new DataColumn();
         //             totime.DataType = typeof(int);
         //             totime.ColumnName = "ToTime";
         //             dt.Columns.Add(totime);

         //             DataColumn place = new DataColumn();
         //             place.DataType = typeof(string);
         //             place.ColumnName = "Place";
         //             dt.Columns.Add(place);

         //             DataColumn clinicname = new DataColumn();
         //             clinicname.DataType = typeof(string);
         //             clinicname.ColumnName = "ClinicName";
         //             dt.Columns.Add(clinicname);

         //             DataColumn streetname = new DataColumn();
         //             streetname.DataType = typeof(string);
         //             streetname.ColumnName = "StreetName";
         //             dt.Columns.Add(streetname);

         //             DataColumn area = new DataColumn();
         //             area.DataType = typeof(string);
         //             area.ColumnName = "Area";
         //             dt.Columns.Add(area);

         //             DataColumn city = new DataColumn();
         //             city.DataType = typeof(string);
         //             city.ColumnName = "City";
         //             dt.Columns.Add(city);

         //             DataColumn state = new DataColumn();
         //             state.DataType = typeof(string);
         //             state.ColumnName = "state";
         //             dt.Columns.Add(state);

         //             DataRow dr;


         //             dr = dt.NewRow();
         //             dr["Day"] = Day;
         //             dr["FromTime"] = FromTime;
         //             dr["ToTime"] = ToTime;
         //             dr["Place"] = Place;
         //             dr["ClinicName"] = ClinicName;
         //             dr["StreetName"] = StreetName;
         //             dr["Area"] = Area;
         //             dr["City"] = City;
         //             dr["State"] = State;
         //             dt.Rows.Add(dr);
         //             dt.AcceptChanges();

         //             HttpContext.Current.Session["datatable"] = dt;  

            
         //}

         public void ScheduleDataClinic(int fkDayId, int FromTime, int ToTime,int fkHospitalId,int fkCityId,int fkStateId,int fkRegistrationId)
         {
             DataColumn fkDay = new DataColumn();
             fkDay.DataType = typeof(Int32);
             fkDay.ColumnName = "fkDayId";
             dt.Columns.Add(fkDay);


             DataColumn fromtime = new DataColumn();
             fromtime.DataType = typeof(Int32);
             fromtime.ColumnName = "FromTime";
             dt.Columns.Add(fromtime);

             DataColumn totime = new DataColumn();
             totime.DataType = typeof(Int32);
             totime.ColumnName = "ToTime";
             dt.Columns.Add(totime);

             DataColumn fkhospital = new DataColumn();
             fkhospital.DataType = typeof(Int32);
             fkhospital.ColumnName = "fkHospitalId";
             dt.Columns.Add(fkhospital);

             DataColumn  fkCity= new DataColumn();
             fkCity.DataType = typeof(Int32);
             fkCity.ColumnName = "fkCityId";
             dt.Columns.Add(fkCity);

             DataColumn fkState = new DataColumn();
             fkState.DataType = typeof(Int32);
             fkState.ColumnName = "fkStateId";
             dt.Columns.Add(fkState);
             

             DataColumn fkRegistration = new DataColumn();
             fkRegistration.DataType = typeof(Int32);
             fkRegistration.ColumnName = "fkRegistrationId";
             dt.Columns.Add(fkRegistration);

             DataRow dr;
            
             dr = dt.NewRow();

             dr["fkDayId"] = fkDay;
             dr["FromTime"] = FromTime;
             dr["ToTime"] = ToTime;
             dr["fkHospitalId"] = fkhospital;
             dr["fkCityId"] = fkCity;
             dr["fkStateId"] = fkState;
             

             dt.Rows.Add(dr);
             dt.AcceptChanges();

             HttpContext.Current.Session["data"] = dt;

         }

#endregion     
    }
}
