﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

/// <summary>
/// Summary description for Clinic_da
/// </summary>
public class Clinic_da
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataAdapter adp;
    DataTable dt;
	public Clinic_da()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString); 
	}

    public int insertclinic(string name, string address, string area, int city, int state)
    {
        cmd = new SqlCommand("strp_clinic", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@Hospital_Name", name);
        cmd.Parameters.AddWithValue("@Street_Name", address);
        cmd.Parameters.AddWithValue("@Area", area);
        cmd.Parameters.AddWithValue("@fkCityID", city);
        cmd.Parameters.AddWithValue("@fkStateID", state);

        int i;

        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }


    public int updt(int pkHospitalId,string name, string address, string area, int city, int state)
    {
        cmd = new SqlCommand("strp_updt_hosp", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkHospitalId", pkHospitalId);
        cmd.Parameters.AddWithValue("@Hospital_Name", name);
        cmd.Parameters.AddWithValue("@Street_Name", address);
        cmd.Parameters.AddWithValue("@Area", area);
        cmd.Parameters.AddWithValue("@fkCityID", city);
        cmd.Parameters.AddWithValue("@fkStateID", state);

        int i;

        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public int del(int pkHospitalId)
    {
        cmd = new SqlCommand("strp_del_hos", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkHospitalId", pkHospitalId);

        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public DataTable fetc(int pkHospitalId)
    {

        cmd = new SqlCommand("Strp_Hospital_fetch", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pkHospitalId", pkHospitalId);
        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }

}