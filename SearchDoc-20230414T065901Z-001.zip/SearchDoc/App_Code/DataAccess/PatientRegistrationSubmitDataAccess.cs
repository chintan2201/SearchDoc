﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

namespace DataAccess
{
    /// <summary>
    /// Summary description for PatientRegistrationSubmitDataAccess
    /// </summary>
    public class PatientRegistrationSubmitDataAccess
    {
        SqlConnection conn;
        SqlCommand cmd;
        public PatientRegistrationSubmitDataAccess()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        }

        public int PatientRegistrationData(string UserName, int fkUserTypeId, string FirstName, string LastName, string DateOfBirth, string Gender, string BloodGroup, string Email, string Password, int fkqueid, string ans, string Street1, string Street2, int fkCityId, int fkCountryId, int fkStateId, int PinCode, Int64 ContactNumber, string SpecificDetail)
        {
            cmd = new SqlCommand("PatientRegistration", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserName", UserName);
            cmd.Parameters.AddWithValue("@fkUserTypeId", fkUserTypeId);
            cmd.Parameters.AddWithValue("@FirstName", FirstName);
            cmd.Parameters.AddWithValue("@LastName", LastName);
            cmd.Parameters.AddWithValue("@DateOfBirth", DateOfBirth);
            cmd.Parameters.AddWithValue("@Gender", Gender);
            cmd.Parameters.AddWithValue("@BloodGroup", BloodGroup);
            cmd.Parameters.AddWithValue("@Email", Email);
            cmd.Parameters.AddWithValue("@Password", Password);
            cmd.Parameters.AddWithValue("@Question", fkqueid);
            cmd.Parameters.AddWithValue("@ans", ans);
            cmd.Parameters.AddWithValue("@Street1", Street1);
            cmd.Parameters.AddWithValue("@Street2", Street2);
            cmd.Parameters.AddWithValue("@fkCityId", fkCityId);
            cmd.Parameters.AddWithValue("@fkCountryId", fkCountryId);
            cmd.Parameters.AddWithValue("@fkStateId", fkStateId);
            cmd.Parameters.AddWithValue("@PinCode", PinCode);
            cmd.Parameters.AddWithValue("@ContactNumber", ContactNumber);
            cmd.Parameters.AddWithValue("@SpecificDetail", SpecificDetail);

            int i;

            try
            {
                conn.Open();
                i = cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                return 0;
            }
            finally
            {
                conn.Close();
            }
            return i;
        }
    }
}