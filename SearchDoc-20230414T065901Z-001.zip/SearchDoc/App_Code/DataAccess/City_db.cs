﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for City_db
/// </summary>
public class City_db
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataAdapter adp;
    DataTable dt;

    public City_db()
    {
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString); 
    }

    public int inscity(string City, int fkStateID)
    {
        cmd = new SqlCommand("strpins_city", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@City", City);
        cmd.Parameters.AddWithValue("@fkStateID", fkStateID);

        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public int updtcity(int pkCityID, string City, int fkStateID)
    {
        cmd = new SqlCommand("strpupdt_city", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkCityID", pkCityID);
        cmd.Parameters.AddWithValue("@City", City);
        cmd.Parameters.AddWithValue("@fkStateID", fkStateID);

        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public int delcity(int pkCityID)
    {
        cmd = new SqlCommand("strpdel_city", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkCityID", pkCityID);

        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public DataTable fetc(int pkCityID)
    {

        cmd = new SqlCommand("Strpcity_fetch", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pkCityID", pkCityID);
        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }

    public DataTable display()
    {

        cmd = new SqlCommand("Strpdiscity_grd", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }

}