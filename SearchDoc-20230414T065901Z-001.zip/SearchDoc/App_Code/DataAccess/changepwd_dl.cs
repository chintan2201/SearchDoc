﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for changepwd_dl
/// </summary>
public class changepwd_dl
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataReader dr;
    public changepwd_dl()
    {
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        conn.Open();
    }

    public void chckuser(string email, string passwrd)
    {


        cmd = new SqlCommand("validuser", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@Email", email);
        cmd.Parameters.AddWithValue("@Password", passwrd);


    }


    public int change(string email, string pass)
    {

        cmd = new SqlCommand("strchngpwd", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Email", email);
        cmd.Parameters.AddWithValue("@Password", pass);
        // cmd.Parameters.AddWithValue("@Confirmpwd", cnfrmpwd);

        int i;


        try
        {
          
            i = cmd.ExecuteNonQuery();

        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

}