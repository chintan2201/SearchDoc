﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

/// <summary>
/// Summary description for schedule_dl
/// </summary>
public class schedule_dl
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataAdapter adp;
    DataTable dt;
	public schedule_dl()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString); 
	}

    public int schedule(int fkDayId, int FromTime, int ToTime, int fkHospitalId, int fkRegistrationId, int fkCityId, int fkStateId,int fkDrId)
    {
        cmd = new SqlCommand("strp_schedule", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@fkDayId",fkDayId);
        cmd.Parameters.AddWithValue("@FromTime",FromTime);
        cmd.Parameters.AddWithValue("@ToTime",ToTime);
        cmd.Parameters.AddWithValue("@fkHospitalId",fkHospitalId);
        cmd.Parameters.AddWithValue("@fkRegistrationId", fkRegistrationId);
        cmd.Parameters.AddWithValue("@fkCityId",fkCityId);
        cmd.Parameters.AddWithValue("@fkStateId", fkStateId);
        cmd.Parameters.AddWithValue("@fkDoctorId",fkDrId);

        int i;

        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public int updtschedule(int pkScheduleId,int fkDayId, int FromTime, int ToTime, int fkHospitalId, int fkRegistrationId, int fkCityId, int fkStateId)
    {
        cmd = new SqlCommand("strp_updtschedule", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkScheduleId", pkScheduleId);
        cmd.Parameters.AddWithValue("@fkDayId", fkDayId);
        cmd.Parameters.AddWithValue("@FromTime", FromTime);
        cmd.Parameters.AddWithValue("@ToTime", ToTime);
        cmd.Parameters.AddWithValue("@fkHospitalId", fkHospitalId);
        cmd.Parameters.AddWithValue("@fkRegistrationId", fkRegistrationId);
        cmd.Parameters.AddWithValue("@fkCityId", fkCityId);
        cmd.Parameters.AddWithValue("@fkStateId", fkStateId);


        int i;

        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }

    public DataTable fetc(int pkScheduleId)
    {

        cmd = new SqlCommand("strp_updtgrd", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@pkScheduleId", pkScheduleId);
        adp = new SqlDataAdapter(cmd);
        dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }

    public int del(int pkScheduleId)
    {
        cmd = new SqlCommand("strp_delschedule", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@pkScheduleId", pkScheduleId);

        int i;
        try
        {
            conn.Open();
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            return 0;
        }
        finally
        {
            conn.Close();
        }
        return i;
    }
    public DataTable fetcd(int fkdrid)
    {

        try
        {
            cmd = new SqlCommand("display", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            //  cmd.Parameters.AddWithValue("@pkScheduleId", pkScheduleId);
            cmd.Parameters.AddWithValue("@pkScheduleId", fkdrid);
            adp = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adp.Fill(dt);
            return dt;
        }
        catch (Exception e) { return dt; }
    }

}