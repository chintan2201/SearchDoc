﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for organ_pro_da
/// </summary>
public class organ_pro_da
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataReader dr;
	public organ_pro_da()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString); 
	}
    public void orgnprofile(int fkRegId)
    {
        conn.Open();

        cmd = new SqlCommand("strp_orgn_pro", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@fkRegistrationId", fkRegId);


        dr = cmd.ExecuteReader();

        if (dr.Read())
        {
            HttpContext.Current.Session["fname"] = dr["First Name"].ToString();
            HttpContext.Current.Session["lname"] = dr["Last Name"].ToString();
            HttpContext.Current.Session["dob"] = dr["Date Of Birth"].ToString();
            HttpContext.Current.Session["gen"] = dr["Gender"].ToString();
            HttpContext.Current.Session["email"] = dr["Email"].ToString();
            HttpContext.Current.Session["bg"] = dr["Blood Group"].ToString();
            HttpContext.Current.Session["Add1"] = dr["Street-1"].ToString();
            HttpContext.Current.Session["Add2"] = dr["Street-1"].ToString();
            HttpContext.Current.Session["city"] = dr["fkCityId"].ToString();
            HttpContext.Current.Session["pin"] = dr["Pin Code"].ToString();
            HttpContext.Current.Session["state"] = dr["fkStateId"].ToString();
            HttpContext.Current.Session["country"] = dr["fkCountryId"].ToString();
            HttpContext.Current.Session["mb"] = dr["Contact Number"].ToString();
            HttpContext.Current.Session["cntctprsn"] = dr["ContactPersonName"].ToString();
            HttpContext.Current.Session["cntctmob"] = dr["ContactPersonMobile"].ToString();
            HttpContext.Current.Session["cntctmail"] = dr["ContactPersonEmail"].ToString();
            HttpContext.Current.Session["drprltn"] = dr["fkRelationID"].ToString();
            HttpContext.Current.Session["drporgntype"] = dr["fkOrganTypeID"].ToString();

            // HttpContext.Current.Session["detail"] = dr["Specific Detail"].ToString();


            //HttpContext.Current.Session["ha"] = dr["HintAns"].ToString();
            //HttpContext.Current.Session["que"] = dr["fkQueId"].ToString();
            conn.Close();
        }

    }
}