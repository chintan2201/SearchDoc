﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

/// <summary>
/// Summary description for forDoctorId
/// </summary>
public class forDoctorId
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataReader dr;
	public forDoctorId()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        conn.Open();
	}

    public int doctorId(int fkRegistrationId)
    {
        int drId;

        cmd = new SqlCommand("find_DoctorId", conn);

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@fkRegistrationId", fkRegistrationId);
      
        try
        {
            
            dr = cmd.ExecuteReader();
            dr.Read();

            dr.HasRows.ToString();

            drId = Convert.ToInt16(dr["pkDoctorId"]);
           
            //   return pw;
        }
        catch (Exception e)
        {
            return 0;

        }
        finally
        {
           conn.Close();
        }
        return drId;


    }
}