﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

namespace DataAccess
{
    /// <summary>
    /// Summary description for UpdateDayData
    /// </summary>
    public class UpdateDayData
    {

        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adp;
        DataTable dt;
        public UpdateDayData()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString);
        }

        public DataTable DayData(int Day, int fkRegistrationId)
        {
            cmd = new SqlCommand("UpdateDay",conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@fkDayId",Day);
            cmd.Parameters.AddWithValue("@fkRegistrationId",fkRegistrationId);
            adp = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adp.Fill(dt);
            return dt;
            
        }
    }
}