﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BusinessLogic;

/// <summary>
/// Summary description for Dr_Profile_da
/// </summary>
public class Dr_Profile_da
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataReader dr;
	
	public Dr_Profile_da()
	{
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SearchDoc"].ConnectionString); 
	}

    public void drprofile(int fkRegId)
    {
        conn.Open();

        cmd = new SqlCommand("str_dr_profile", conn);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@fkRegistrationId", fkRegId);


        dr = cmd.ExecuteReader();

        if (dr.Read())
        {
            HttpContext.Current.Session["fname"] = dr["First Name"].ToString();
            HttpContext.Current.Session["lname"] = dr["Last Name"].ToString();
            HttpContext.Current.Session["dob"] = dr["Date Of Birth"].ToString();
            HttpContext.Current.Session["gen"] = dr["Gender"].ToString();
            HttpContext.Current.Session["email"] = dr["Email"].ToString();
            HttpContext.Current.Session["bg"] = dr["Blood Group"].ToString();
            HttpContext.Current.Session["Add1"] = dr["Street-1"].ToString();
            HttpContext.Current.Session["Add2"] = dr["Street-1"].ToString();
            HttpContext.Current.Session["city"] = dr["fkCityId"].ToString();
            HttpContext.Current.Session["pin"] = dr["Pin Code"].ToString();
            HttpContext.Current.Session["state"] = dr["fkStateId"].ToString();
            HttpContext.Current.Session["country"] = dr["fkCountryId"].ToString();
            HttpContext.Current.Session["mb"] = dr["Contact Number"].ToString();
            HttpContext.Current.Session["photo"] = dr["photo"].ToString();
            HttpContext.Current.Session["spec"] = dr["fkSpecialityId"].ToString();

            HttpContext.Current.Session["fkdr"] = dr["fkDoctorId"].ToString();
            HttpContext.Current.Session["gradyr"] = dr["Graduation Year"].ToString();
            HttpContext.Current.Session["fkgradclg"] = dr["fkGraduationCollege"].ToString();
            HttpContext.Current.Session["pgyr"] = dr["PostGraduation Year"].ToString();
            HttpContext.Current.Session["fkpgclg"] = dr["fkPgCollege"].ToString();


           // HttpContext.Current.Session["detail"] = dr["Specific Detail"].ToString();
           //HttpContext.Current.Session["ha"] = dr["HintAns"].ToString();
           //HttpContext.Current.Session["que"] = dr["fkQueId"].ToString();
            conn.Close();
        }

    }
}