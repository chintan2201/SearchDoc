﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for URL
/// </summary>
public class URL
{
	public URL()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static readonly string home = "home.aspx";
    public static readonly string doctor = "Dr.aspx";
    public static readonly string patient = "Patient.aspx";
    public static readonly string admin = "Admin.aspx";
    public static readonly string forgot_password = "forgot_password.aspx";
    public static readonly string registration = "Registration.aspx";
    public static readonly string searching = "searching.aspx";
    public static readonly string FAQ = "FAQ.aspx";
    public static readonly string Aboutus = "AboutUs.aspx";
    public static readonly string contactus = "Contact_Us.aspx";
    public static readonly string create_schedule = "schedule.aspx";
    public static readonly string update_Schedule = "updt_schedule.aspx";
    public static readonly string organ_Donate = "Organ_Donate.aspx";
    public static readonly string EditProfileDoctor = "EditProfileDoctor.aspx";
    public static readonly string Searching1 = "Searching1.aspx";
    public static readonly string Searching_Patient = "Searching_patient.aspx";
    public static readonly string organDonate_Patient = "OrganDonate_Patient.aspx";
    public static readonly string organdonator = "organ_Donate.aspx";
    public static readonly string organDonate_Doc = "OrganDonate_Doctor.aspx";
}