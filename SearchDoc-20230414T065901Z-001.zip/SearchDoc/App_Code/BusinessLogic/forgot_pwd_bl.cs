﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for forgot_pwd_bl
/// </summary>
public class forgot_pwd_bl
{
    forgot__pwd_dl pwd = new forgot__pwd_dl();

    private string _EmailID;
    private int _fkQueId;
    private string _HintAns;

	public forgot_pwd_bl()
	{
	}
    public forgot_pwd_bl(string EmailID, int fkQueId, string HintAns)
    {
        _EmailID = EmailID;
        _fkQueId = fkQueId;
        _HintAns = HintAns;
    }

    public int fkQueId
    {
        get
        {
            return _fkQueId;
        }
        set
        {
            _fkQueId = value;
        }

    }

    public string EmailID
    {
        get
        {
            return _EmailID;
        }
        set
        {
            _EmailID = value;
        }

    }
    public string HintAns
    {
        get
        {
            return _HintAns;
        }
        set
        {
            _HintAns = value;
        }

    }


    public string recpwd()
    {
        return (pwd.recover(this._EmailID, this._fkQueId, this._HintAns));
    }
}