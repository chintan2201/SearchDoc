﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
/// <summary>
/// Summary description for Drp_Fill_bl
/// </summary>
public class Drp_Fill_bl
{
    Drp_Fill_da obj = new Drp_Fill_da();
	public Drp_Fill_bl()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable que()
    {
        return obj.quefun();
    }
    public DataTable gradclg()
    {
        return obj.gradclg();
    }
    public DataTable pgclg()
    {
        return obj.pgclg();
    }
    public DataTable spec()
    {
        return obj.spec();
    }
    public DataTable city()
    {
        return obj.city();
    }
    public DataTable state()
    {
        return obj.state();
    }
    public DataTable hospital()
    {
        return obj.hos();
    }

}