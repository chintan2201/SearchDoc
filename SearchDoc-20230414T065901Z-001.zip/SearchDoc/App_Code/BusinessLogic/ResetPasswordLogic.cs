﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;

namespace BusinessLogic
{
    /// <summary>
    /// Summary description for ResetPasswordLogic
    /// </summary>
    public class ResetPasswordLogic
    {
        private string _Email;
        private string _Password;
        public ResetPasswordLogic(string Email, string Password)
        {
            _Email = Email;
            _Password = Password;
        }
        public ResetPasswordLogic()
        {

        }

        public string Email
        {
            get
            {
                return _Email;
            }
            set
            {
                _Email = value;
            }
        }

        public string Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }

        public void NewPasswordLogic(string Email, string Password)
        {
            try
            {
                ResetPasswordData d1 = new ResetPasswordData();
                d1.NewPasswordData(this._Email, this._Password);
            }
            catch (Exception e)
            {

            }
        }
    }
}