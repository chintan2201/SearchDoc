﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Dr_Profile_bl
/// </summary>
public class Dr_Profile_bl
{ 
    Dr_Profile_da dr=new Dr_Profile_da();
    private int _pkPatientId;
    private string _FirstName;
    private string _LastName;
    private string _DateOfBirth;
    private string _Gender;
    private string _Email;
    private string _BloodGroup;
    private string _Street1;
    private string _Street2;
    private int _fkCityId;
    private Int64 _PinCode;
    private int _fkStateId;
    private int _fkCountryId;
    private Int64 _ContactNumber;
    private string _SpecificDetail;
    private int _fkRegistrationId;
    private string _photo;

    private int _pkGraduationId;
    private int _fkDoctorId;
    private int _Graduationyr;
    private int _fkGraduationclg;
    private int _pgyr;
    private int _fkpgclg;


    private int _fkSpecialityId;
   
	public Dr_Profile_bl()
	{
	}

    public Dr_Profile_bl(int fkRegistrationId)
    {
        _fkRegistrationId = fkRegistrationId;
    }

    private int fkSpecialityId
    {
        get
        {
            return _fkSpecialityId;
        }
        set
        {
            _fkSpecialityId = value;
        }
    }

    public string photo
    {
        get
        {
            return _photo;
        }
        set
        {
            _photo = value;
        }
    }

    public int pkGraduationId
    {
        get
        {
            return _pkGraduationId;
        }
        set
        {
            _pkGraduationId = value;
        }
    }

    public int fkDoctorId
    {
        get
        {
            return _fkDoctorId;
        }
        set
        {
            _fkDoctorId = value;
        }
    }

    public int graduationyr
    {
        get
        {
            return _Graduationyr;
        }
        set
        {
            _Graduationyr = value;
        }
    }

    public int fkgraduationclg
    {
        get
        {
            return _fkGraduationclg;
        }
        set
        {
            _fkGraduationclg = value;
        }
    }
    public int pgyr
    {
        get
        {
            return _pgyr;
        }
        set
        {
            _pgyr = value;
        }
    }

    public int fkpgclg
    {
        get
        {
            return _fkpgclg;
        }
        set
        {
            _fkpgclg = value;
        }
    }


    public string FirstName
    {
        get
        {
            return _FirstName;
        }
        set
        {
            _FirstName = value;
        }
    }

    public string LastName
    {
        get
        {
            return _LastName;
        }
        set
        {
            _LastName = value;
        }
    }

    public string DateOfBirth
    {
        get
        {
            return _DateOfBirth;
        }
        set
        {
            _DateOfBirth = value;
        }
    }

    public string Gender
    {
        get
        {
            return _Gender;
        }
        set
        {
            _Gender = value;
        }
    }

    public string BloodGroup
    {
        get
        {
            return _BloodGroup;
        }
        set
        {
            _BloodGroup = value;
        }
    }

    public string Email
    {
        get
        {
            return _Email;
        }
        set
        {
            _Email = value;
        }
    }

    
    public string Street1
    {
        get
        {
            return _Street1;
        }
        set
        {
            _Street1 = value;
        }
    }

    public string Street2
    {
        get
        {
            return _Street2;
        }
        set
        {
            _Street2 = value;
        }
    }

    public int fkCityId
    {
        get
        {
            return _fkCityId;
        }
        set
        {
            _fkCityId = value;
        }
    }

    public int fkCountryId
    {
        get
        {
            return _fkCountryId;
        }
        set
        {
            _fkCountryId = value;
        }
    }

    public int fkStateId
    {
        get
        {
            return _fkStateId;
        }
        set
        {
            _fkStateId = value;
        }
    }

    public Int64 PinCode
    {
        get
        {
            return _PinCode;
        }
        set
        {
            _PinCode = value;
        }
    }
    public Int64 ContactNumber
    {
        get
        {
            return _ContactNumber;
        }
        set
        {
            _ContactNumber = value;
        }
    }

    public string SpecificDetail
    {
        get
        {
            return _SpecificDetail;
        }
        set
        {
            _SpecificDetail = value;
        }
    }

    public int fkRegistrationId
    {
        get
        {
            return _fkRegistrationId;
        }
        set
        {
            _fkRegistrationId = fkRegistrationId;
        }
    }


    public void display(int fkRegistrationId)
    {
        dr.drprofile(fkRegistrationId);
    }


}