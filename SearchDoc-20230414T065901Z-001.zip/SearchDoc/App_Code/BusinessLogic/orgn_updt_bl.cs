﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for orgn_updt_bl
/// </summary>
public class orgn_updt_bl
{
    orgn_updt_da organ = new orgn_updt_da();
    private string _FirstName;
    private string _LastName;
    private string _DateOfBirth;
    private string _Gender;
    private string _Email;
    private string _BloodGroup;
    private string _Street1;
    private string _Street2;
    private int _fkCityId;
    private Int64 _PinCode;
    private int _fkStateId;
    private int _fkCountryId;
    private Int64 _ContactNumber;
      private string _ContactPersonName;
    private Int64 _ContactPersonMobile;
    private string _ContactPersonEmail;
    private int _fkRelationID;
    private int _fkOrganTypeID;
    private int _fkRegistrationId;

	
    public orgn_updt_bl(string fname, string lname, string dob, string gender, string email, string bg, string street1, string street2, int fkCityid, Int64 pin, int fkStateId, int fkCountryId, Int64 mb,string cntctprsn,Int64 cntctprsnmob,string cntctmail,int drprltn,int drporgn,int fkRegistrationId)
    {

        _FirstName = fname;
        _LastName = lname;
        _DateOfBirth = dob;
        _Gender = gender;
        _Email = email;
        _BloodGroup = bg;
        _Street1 = street1;
        _Street2 = street2;
        _fkCityId = fkCityid;
        _PinCode = pin;
        _fkStateId = fkStateId;
        _fkCountryId = fkCountryId;
        _ContactNumber = mb;
        _ContactPersonName = cntctprsn;
        _ContactPersonMobile = cntctprsnmob;
        _ContactPersonEmail = cntctmail;
        _fkRelationID = drprltn;
        _fkOrganTypeID = drporgn;
        _fkRegistrationId = fkRegistrationId;
    }
	public orgn_updt_bl()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string FirstName
    {
        get
        {
            return _FirstName;
        }
        set
        {
            _FirstName = value;
        }
    }

    public string LastName
    {
        get
        {
            return _LastName;
        }
        set
        {
            _LastName = value;
        }
    }

    public string DateOfBirth
    {
        get
        {
            return _DateOfBirth;
        }
        set
        {
            _DateOfBirth = value;
        }
    }

    public string Gender
    {
        get
        {
            return _Gender;
        }
        set
        {
            _Gender = value;
        }
    }

    public string BloodGroup
    {
        get
        {
            return _BloodGroup;
        }
        set
        {
            _BloodGroup = value;
        }
    }

    public string Email
    {
        get
        {
            return _Email;
        }
        set
        {
            _Email = value;
        }
    }


    public string Street1
    {
        get
        {
            return _Street1;
        }
        set
        {
            _Street1 = value;
        }
    }

    public string Street2
    {
        get
        {
            return _Street2;
        }
        set
        {
            _Street2 = value;
        }
    }

    public int fkCityId
    {
        get
        {
            return _fkCityId;
        }
        set
        {
            _fkCityId = value;
        }
    }

    public int fkCountryId
    {
        get
        {
            return _fkCountryId;
        }
        set
        {
            _fkCountryId = value;
        }
    }

    public int fkStateId
    {
        get
        {
            return _fkStateId;
        }
        set
        {
            _fkStateId = value;
        }
    }

    public Int64 PinCode
    {
        get
        {
            return _PinCode;
        }
        set
        {
            _PinCode = value;
        }
    }
    public Int64 ContactNumber
    {
        get
        {
            return _ContactNumber;
        }
        set
        {
            _ContactNumber = value;
        }
    }
    public string ContactPersonName
    {
        get
        {
            return _ContactPersonName;
        }
        set
        {
            _ContactPersonName = value;
        }
    }
    public string ContactPersonEmail
    {
        get
        {
            return _ContactPersonEmail;
        }
        set
        {
            _ContactPersonEmail = value;
        }
    }
    public Int64 ContactPersonMobile
    {
        get
        {
            return _ContactPersonMobile;
        }
        set
        {
            _ContactPersonMobile = value;
        }
    }
    public int fkRelationID
    {
        get
        {
            return _fkRelationID;
        }
        set
        {
            _fkRelationID = value;
        }
    }
    public int fkOrganTypeID
    {
        get
        {
            return _fkOrganTypeID;
        }
        set
        {
            _fkOrganTypeID = value;
        }
    }
    public int fkRegistrationId
    {
        get
        {
            return _fkRegistrationId;
        }
        set
        {
            _fkRegistrationId = fkRegistrationId;
        }
    }
    public int update(int fkRegistrationId)
    {
        return (organ.orgn_updt(this._FirstName, this._LastName, this._DateOfBirth, this._Gender, this._Email, this._BloodGroup, this._Street1, this._Street2, this._fkCityId, this._PinCode, this._fkStateId, this._fkCountryId, this._ContactNumber, this._ContactPersonName, this._ContactPersonMobile, this._ContactPersonEmail, this._fkRelationID, this._fkOrganTypeID, fkRegistrationId));
    //return (organ.orgn_updt(FirstName,LastName,DateOfBirth,Gender,Email,BloodGroup,Street1,Street2,fkCityId,PinCode,fkStateId,fkCountryId,ContactNumber,ContactPersonName,ContactPersonMobile,ContactPersonEmail,._fkRelationID,this._fkOrganTypeID,fkRegistrationId));
    }
}