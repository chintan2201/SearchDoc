﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;

namespace BusinessLogic

{

    /// <summary>
    /// Summary description for logicDropdown
    /// </summary>
    public class logicDropdown
    {
        private int _pkStateId;
        public logicDropdown(int pkStateId)
        {
            _pkStateId = pkStateId;
        }
        public logicDropdown()
        {
           
        }

        public int pkStateId
        {
            get 
            {
                return _pkStateId;
            }
            set
            {
                _pkStateId = value;
            }
        }


        public DataTable specialityLogic()
        {
            try
            {
                DropdownDataAccess d = new DropdownDataAccess();
                return d.specialityData();
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public DataTable StateLogic()
        {
            try
            {
                DropdownDataAccess d = new DropdownDataAccess();
                return d.StateData();
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public DataTable CityLogic(int pkStateId)
        {
            try
            {
                DropdownDataAccess d = new DropdownDataAccess();
                return d.CityData(this._pkStateId);
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public DataTable HospitalLogic()
        {
            try
            {
                DropdownDataAccess d = new DropdownDataAccess();
                return d.HospitalData();
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public DataTable DoctorLogic()
        {
            try
            {
                DropdownDataAccess d = new DropdownDataAccess();
                return d.DoctorData();
            }
            catch (Exception e)
            {
                return null;
            }
        }
    }
}