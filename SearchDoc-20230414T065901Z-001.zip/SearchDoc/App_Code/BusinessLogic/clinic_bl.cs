﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
/// <summary>
/// Summary description for clinic_bl
/// </summary>
public class clinic_bl
{
    Clinic_da cd = new Clinic_da();

    private int _PkHospitalID;
    private string _Name;
    private string _Address;
    private string _Area;
    private int _fkCityID;
    private int _fkStateID;

	public clinic_bl()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public clinic_bl(string Name, string Address, string Area, int fkCityID, int fkStateID)
    {
        _Name = Name;
        _Address = Address;
        _Area = Area;
        _fkCityID = fkCityID;
        _fkStateID = fkStateID;
    }

    public int PkHospitalID
    {
        get
        {
            return _PkHospitalID;
        }
        set
        {
            _PkHospitalID = value;
        }
    }

    public string Name
    {
        get
        {
            return _Name;
        }
        set
        {
            _Name = value;
        }
    }

    public string Address
    {
        get
        {
            return _Address;
        }
        set
        {
            _Address = value;
        }
    }
    public string Area
    {
        get
        {
            return _Area;
        }
        set
        {
            _Area = value;
        }
    }
    public int fkCityID
    {
        get
        {
            return _fkCityID;
        }
        set
        {
            _fkCityID = value;
        }
    }
    public int fkStateID
    {
        get
        {
            return _fkStateID;
        }
        set
        {
            _fkStateID = value;
        }
    }
    public int ins()
    {
        try
        {
            return cd.insertclinic(this._Name, this._Address, this._Area, this._fkCityID, this._fkStateID);
        }
        catch (Exception e)
        {
            return 0;
        }
    }

    public int updt(int pkHospitalId)
    {
        try
        {
            return cd.updt(pkHospitalId,this._Name, this._Address, this._Area, this._fkCityID, this._fkStateID);
        }
        catch (Exception e)
        {
            return 0;
        }
    }

    public int delcit(int pkHospitalId)
    {
        try
        {
            return cd.del(pkHospitalId);
        }
        catch (Exception e)
        {
            return 0;
        }
    }

    public DataTable fetch(int pkHospitalId)
    {
        return cd.fetc(pkHospitalId);
    }
}