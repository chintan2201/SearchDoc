﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;

namespace BusinessLogic
{
    /// <summary>
    /// business logic class for login form
    /// </summary>
    public class LoginLogic
    {
        private int _pkRegistrationId;
        private string _UserName;
        private string _Password;
        private string _Email;

        #region Login Constructer
        /// <summary>
        /// Login constructer
        /// </summary>
        /// <param name="pkRegistrationId"></param>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>

        public LoginLogic(int pkRegistrationId, string UserName, string Password,string Email)
        {
            _pkRegistrationId = pkRegistrationId;
            _UserName = UserName;
            _Password = Password;
            _Email = Email;
        }

        public LoginLogic()
        {
        }
        #endregion

        #region get-set for Login
        /// <summary>
        /// get-set property
        /// </summary>
        public int pkRegistrationId
        {
            get
            {
                return _pkRegistrationId;
            }
            set
            {
                _pkRegistrationId = value;
            }
        }

        public string UserName
        {
            get
            {
                return _UserName;
            }
            set
            {
                _UserName = value;
            }
        }

        public string Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }

        public string Email
        {
            get
            {
                return _Email;
            }
            set
            {
                _Email = value;
            }
        }

        #endregion

        #region Login Method
        /// <summary>
        /// login method
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        public void Login_l(string UserName, string Password)
        {
            try
            {
                login_data d1 = new login_data();
                d1.Login_d(this._UserName, this._Password);
            }
            catch (Exception e)
            {

            }
        }
        #endregion

        public void EmailCheckLogic(string Email)
        {
            try
            {
                login_data d1 = new login_data();
                d1.EmailCheckData(this._Email);
            }
            catch (Exception e)
            { 
            
            }
        }
    }
}