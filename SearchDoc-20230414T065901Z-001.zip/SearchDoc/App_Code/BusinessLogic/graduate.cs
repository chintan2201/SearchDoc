﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for graduate
/// </summary>
public class graduate
{
    graduate_db g = new graduate_db();

    private int _pkGraduationCollege;
    private string _Graduation_College;


	public graduate()
	{
    }

    public graduate(int pkGraduationCollege, string Graduation_College)
    {
        _pkGraduationCollege = pkGraduationCollege;
        _Graduation_College = Graduation_College;

    }
    public graduate(int pkGraduationCollege)
    {
        _pkGraduationCollege = pkGraduationCollege;
    }
    public graduate(string Graduation_College)
    {
        _Graduation_College = Graduation_College;
    }

    public int pkGraduationCollege
    {
        get
        {
            return _pkGraduationCollege;
        }
        set
        {
            _pkGraduationCollege = value;
        }
    }

    public string Graduation_College
    {
        get
        {
            return _Graduation_College;
        }
        set
        {
            _Graduation_College = value;
        }
    }

    public int ins()
    {
        try
        {
            return g.insgraduate(this._Graduation_College);
        }
        catch (Exception e)
        {
            return 0;
        }
    }

    public int updt(int pkGraduationCollege)
    {
        try
        {
            return g.updt(pkGraduationCollege, this._Graduation_College);
        }
        catch (Exception e)
        {
            return 0;
        }
    }

    public int delcit(int pkGraduationCollege)
    {
        try
        {
            return g.del(pkGraduationCollege);
        }
        catch (Exception e)
        {
            return 0;
        }
    }
    public DataTable fetch(int pkGraduationCollege)
    {
        return g.fetc(pkGraduationCollege);
    }

}