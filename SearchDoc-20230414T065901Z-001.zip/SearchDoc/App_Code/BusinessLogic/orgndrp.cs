﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for orgndrp
/// </summary>
public class orgndrp
{
    orgndrpdb orgndb = new orgndrpdb();
    Organregistration orgreg = new Organregistration();

    private string _UserName;
    private int _fkUserTypeId;
    private string _FirstName;
    private string _LastName;
    private string _DateOfBirth;
    private string _Gender;
    private string _BloodGroup;
    private string _Email;
    private string _Password;
    private int _fkqueid;
    private string _ans;
    private string _Street1;
    private string _Street2;
    private int _fkCityId;
    private int _fkCountryId;
    private int _fkStateId;
    private int _PinCode;
    private Int64 _ContactNumber;
    private string _ContactPersonName;
    private Int64 _ContactPersonMobile;
    private string _ContactPersonEmail;
    private int _fkRelationID;
    private int _fkOrganTypeID;
    private int _fkRegistrationId;

    public orgndrp(string UserName, int fkUserTypeId, string FirstName, string LastName, string DateOfBirth, string Gender, string BloodGroup, string Email, string Password, int fkqueid, string ans, string Street1, string Street2, int fkCityId, int fkCountryId, int fkStateId, int PinCode, Int64 ContactNumber, string ContactPersonName, Int64 ContactPersonMobile, string ContactPersonEmail, int fkRelationID, int fkOrganTypeID)
    {
        _UserName = UserName;
        _fkUserTypeId = fkUserTypeId;
        _FirstName = FirstName;
        _LastName = LastName;
        _DateOfBirth = DateOfBirth;
        _Gender = Gender;
        _BloodGroup = BloodGroup;
        _Email = Email;
        _Password = Password;
        _Street1 = Street1;
        _Street2 = Street2;
        _fkCityId = fkCityId;
        _fkCountryId = fkCountryId;
        _fkStateId = fkStateId;
        _PinCode = PinCode;
        _ContactNumber = ContactNumber;
        _ContactPersonName = ContactPersonName;
        _ContactPersonMobile = ContactPersonMobile;
        _ContactPersonEmail = ContactPersonEmail;
        _fkRelationID = fkRelationID;
        _fkOrganTypeID = fkOrganTypeID;
        // _fkRegistrationId = fkRegistrationId;
    }
    public orgndrp()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public string UserName
    {
        get
        {
            return _UserName;
        }
        set
        {
            _UserName = value;
        }
    }

    public int fkUserTypeId
    {
        get
        {
            return _fkUserTypeId;
        }
        set
        {
            _fkUserTypeId = value;
        }
    }

    public string FirstName
    {
        get
        {
            return _FirstName;
        }
        set
        {
            _FirstName = value;
        }
    }

    public string LastName
    {
        get
        {
            return _LastName;
        }
        set
        {
            _LastName = value;
        }
    }
    public string ContactPersonName
    {
        get
        {
            return _ContactPersonName;
        }
        set
        {
            _ContactPersonName = value;
        }
    }
    public string ContactPersonEmail
    {
        get
        {
            return _ContactPersonEmail;
        }
        set
        {
            _ContactPersonEmail = value;
        }
    }
    public Int64 ContactPersonMobile
    {
        get
        {
            return _ContactPersonMobile;
        }
        set
        {
            _ContactPersonMobile = value;
        }
    }
    public int fkRelationID
    {
        get
        {
            return _fkRelationID;
        }
        set
        {
            _fkRelationID = value;
        }
    }
    public int fkOrganTypeID
    {
        get
        {
            return _fkOrganTypeID;
        }
        set
        {
            _fkOrganTypeID = value;
        }
    }
    //public int fkRegistrationId
    //{
    //    get
    //    {
    //        return _fkRegistrationId;
    //    }
    //    set
    //    {
    //        _fkRegistrationId = value;
    //    }
    //}

    public string DateOfBirth
    {
        get
        {
            return _DateOfBirth;
        }
        set
        {
            _DateOfBirth = value;
        }
    }

    public string Gender
    {
        get
        {
            return _Gender;
        }
        set
        {
            _Gender = value;
        }
    }

    public string BloodGroup
    {
        get
        {
            return _BloodGroup;
        }
        set
        {
            _BloodGroup = value;
        }
    }

    public string Email
    {
        get
        {
            return _Email;
        }
        set
        {
            _Email = value;
        }
    }

    public string Password
    {
        get
        {
            return _Password;
        }
        set
        {
            _Password = value;
        }
    }

    public string Street1
    {
        get
        {
            return _Street1;
        }
        set
        {
            _Street1 = value;
        }
    }

    public string Street2
    {
        get
        {
            return _Street2;
        }
        set
        {
            _Street2 = value;
        }
    }

    public int fkCityId
    {
        get
        {
            return _fkCityId;
        }
        set
        {
            _fkCityId = value;
        }
    }

    public int fkCountryId
    {
        get
        {
            return _fkCountryId;
        }
        set
        {
            _fkCountryId = value;
        }
    }

    public int fkStateId
    {
        get
        {
            return _fkStateId;
        }
        set
        {
            _fkStateId = value;
        }
    }

    public int PinCode
    {
        get
        {
            return _PinCode;
        }
        set
        {
            _PinCode = value;
        }
    }
    public Int64 ContactNumber
    {
        get
        {
            return _ContactNumber;
        }
        set
        {
            _ContactNumber = value;
        }
    }

    public int fkqueid
    {
        get
        {
            return _fkqueid;
        }
        set
        {
            _fkqueid = value;
        }
    }

    public string ans
    {
        get
        {
            return _ans;
        }
        set
        {
            _ans = value;
        }
    }

    public int OrganRegistration(string UserName, int fkUserTypeId, string FirstName, string LastName, string DateOfBirth, string Gender, string BloodGroup, string Email, string Password, int fkqueid, string ans, string Street1, string Street2, int fkCityId, int fkCountryId, int fkStateId, int PinCode, Int64 ContactNumber, string ContactPersonName, Int64 ContactPersonMobile, string ContactPersonEmail, int fkRelationID, int fkOrganTypeID)
    {
        try
        {
            return (orgreg.intorgnregdb(this._UserName, this._fkUserTypeId, this._FirstName, this._LastName, this._DateOfBirth, this._Gender, this._BloodGroup, this._Email, this._Password, this._fkqueid, this._ans, this._Street1, this._Street2, this._fkCityId, this._fkCountryId, this._fkStateId, this._PinCode, this._ContactNumber, this._ContactPersonName, this._ContactPersonMobile, this._ContactPersonEmail, this._fkRelationID, this._fkOrganTypeID));
        }
        catch (Exception e)
        {
            return 0;
        }

    }
    public DataTable relation()
    {
        return orgndb.relationdb();
    }
    public DataTable organtype()
    {
        return orgndb.organtypedb();
    }


}