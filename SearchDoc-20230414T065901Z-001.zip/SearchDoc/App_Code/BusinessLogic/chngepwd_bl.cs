﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for chngepwd_bl
/// </summary>
public class chngepwd_bl
{
    changepwd_dl chpwd = new changepwd_dl();
    private string _Email;
    private string _Password;
    private string _Confirmpwd;
    private string _pass;

    public chngepwd_bl()
    {

    }
    public chngepwd_bl(string email, string passwrd)
    {

        _Email = email;
        _Password = passwrd;
    }
    public chngepwd_bl(string email, string pass, string cnfrmpwd)
    {
        _Email = email;
        _pass = pass;
        _Confirmpwd = cnfrmpwd;
    }

    public string pass
    {
        get
        {
            return _pass;
        }
        set
        {
            _pass = value;
        }
    }

    public string email
    {
        get
        {
            return _Email;
        }
        set
        {
            _Email = value;
        }

    }
    public string passwrd
    {
        get
        {
            return _Password;
        }
        set
        {
            _Password = value;
        }

    }

    public string cnfrmpwd
    {
        get
        {
            return _Confirmpwd;
        }
        set
        {
            _Confirmpwd = value;
        }

    }

    public void loguser()
    {
        chpwd.chckuser(email, passwrd);
    }
    public int updtpwd()
    {
        return (chpwd.change(this._Email, this._pass));

    }

}