﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;
/// <summary>
/// Summary description for SearchLogic
/// </summary>

namespace BusinessLogic
{
    public class SearchLogic
    {

        private int _fkSpecialityId;
        private int _fkHospitalId;
        private int _fkStateId;
        private int _fkCityId;
        private string _FirstName;

        public SearchLogic(int fkSpecialityId, int fkHospitalId, int fkStateId, int fkCityId, string FirstName)
        {
            _fkSpecialityId = fkSpecialityId;
            _fkHospitalId = fkHospitalId;
            _fkStateId = fkStateId;
            _fkCityId = fkCityId;
            _FirstName = FirstName;
        }
        

        public SearchLogic()
        {
           
        }

        public int fkSpecialityId
        {
            get
            {
                return _fkSpecialityId;
            }
            set
            {
                _fkSpecialityId = value;
            }
        }

        public int fkHospitalId
        {
            get
            {
                return _fkHospitalId;
            }
            set
            {
                _fkHospitalId = value;
            }
        }

        public int fkStateId
        {
            get
            {
                return _fkStateId;
            }
            set
            {
                _fkStateId = value;
            }
        }

        public int fkCityId
        {
            get
            {
                return _fkCityId;
            }
            set
            {
                _fkCityId = value;
            }
        }

        public string FirstName
        {
            get
            {
                return _FirstName;
            }
            set
            {
                _FirstName = value;
            }
        }


        public DataTable SearchingDoctorLogic(int fkSpecialityId, int fkHospitalId, int fkStateId, int fkCityId, string FirstName)
        {
            try
            {
                SearchDataAccess d = new SearchDataAccess();
                return (d.SearchingDoctorData(this._fkSpecialityId, this._fkHospitalId, this._fkStateId, this._fkCityId, this._FirstName));
            }

            catch (Exception e)
            {
                return null;
            }
        }
    }
}