﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;



namespace BusinessLogic
{
    /// <summary>
    /// Summary description for CreateScheduleLogic
    /// </summary>
  
    public class CreateScheduleLogic
    {

        //private int _pkScheduleId;
        //private int _fkDoctorId;
        private Int32 _fkDayId;
        private Int32 _FromTime;
        private Int32 _ToTime;
        private Int32 _fkhospitalId;
        //private string _Area;
        private Int32 _fkCityId;
        private Int32 _fkStateId;
        private Int32 _fkRegistrationId;

        public CreateScheduleLogic(int fkDayId, int FromTime, int ToTime, int fkhospitalId,int fkCityId,int fkStateId,int fkRegistrationId)
        {
            //_pkScheduleId = pkScheduleId;
            //_fkDoctorId = fkDoctorId;
            _fkDayId = fkDayId;
            _FromTime = FromTime;
            _ToTime = ToTime;
            _fkhospitalId = fkhospitalId;
           // _Area = Area;
            _fkCityId = fkCityId;
            _fkStateId = fkStateId;
            _fkRegistrationId = fkRegistrationId;
        }

        public CreateScheduleLogic()
        {

        }

        #region get-set property
        //public int pkScheduleId
        //{
        //    get
        //    {
        //        return _pkScheduleId;
        //    }
        //    set
        //    {
        //        _pkScheduleId = value;
        //    }
        //}

        //public int fkDoctorId
        //{
        //    get
        //    {
        //        return _fkDoctorId;
        //    }
        //    set
        //    {
        //        _fkDoctorId = value;
        //    }
        //}

        public Int32 fkRegistrationId
        {
            get
            {
                return _fkRegistrationId;
            }
            set
            {
                _fkRegistrationId = value ;
            }
        }

        public Int32 fkDayId
        {
            get
            {
                return _fkDayId;
            }
            set
            {
                _fkDayId = value;
            }
        }


        public Int32 FromTime
        {
            get
            {
                return _FromTime;
            }
            set
            {
                _FromTime = value;
            }
        }
        public Int32 ToTime
        {
            get
            {
                return _ToTime;
            }
            set
            {
                _ToTime = value;
            }
        }
        public Int32 fkhospitalId
        {
            get
            {
                return _fkhospitalId;
            }
            set
            {
                _fkhospitalId = value;
            }
        }

        //public string Area
        //{
        //    get
        //    {
        //        return _Area;
        //    }
        //    set
        //    {
        //        _Area = value;
        //    }
        //}

        public Int32 fkCityId
        {
            get
            {
                return _fkCityId;
            }
            set
            {
                _fkCityId = value;
            }
        }

        public Int32 fkStateId
        {
            get
            {
                return _fkStateId;
            }
            set
            {
                _fkStateId = value;
            }
        }
        #endregion

        #region Add place
        /// <summary>
        /// Add place logic
        /// </summary>
        /// <param name="Day"></param>
        /// <param name="FromTime"></param>
        /// <param name="ToTime"></param>
        /// <param name="Place"></param>

      //  public void AddPlace()
      //{
      //    try
      //    {
      //        ScheduleDataAccess d1 = new ScheduleDataAccess();
      //        d1.ScheduleData(this._fkDayId, this._FromTime, this._ToTime, this._fkhospitalId, this._fkCityId, this._fkStateId);

      //    }
      //    catch (Exception e)
      //    { 
          
      //    }
      //}

        public void AddPlaceClinic()
        {
            try
            {
                ScheduleDataAccess d1 = new ScheduleDataAccess();
                d1.ScheduleDataClinic(this._fkDayId, this._FromTime, this._ToTime, this._fkhospitalId, this._fkCityId, this._fkStateId,this._fkRegistrationId);

            }
            catch (Exception e)
            {

            }
        }

        #endregion

      
       
    }
}