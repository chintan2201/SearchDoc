﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for pgcollege
/// </summary>
public class pgcollege
{
    pgcollege_db g = new pgcollege_db();
    private int _pkPGraduationCollege;
    private string _PGraduation_College;

	public pgcollege()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public pgcollege(int pkPGraduationCollege, string PGraduation_College)
    {
        _pkPGraduationCollege = pkPGraduationCollege;
        _PGraduation_College = PGraduation_College;

    }
    public pgcollege(int pkGraduationCollege)
    {
        _pkPGraduationCollege = pkGraduationCollege;
    }
    public pgcollege(string Graduation_College)
    {
        _PGraduation_College = Graduation_College;
    }

    public int pkGraduationCollege
    {
        get
        {
            return _pkPGraduationCollege;
        }
        set
        {
            _pkPGraduationCollege = value;
        }
    }

    public string Graduation_College
    {
        get
        {
            return _PGraduation_College;
        }
        set
        {
            _PGraduation_College = value;
        }
    }

    public int ins()
    {
        try
        {
            return g.ins(this._PGraduation_College);
        }
        catch (Exception e)
        {
            return 0;
        }
    }

    public int updt(int pkPGraduationCollege)
    {
        try
        {
            return g.updt(pkPGraduationCollege, this._PGraduation_College);
        }
        catch (Exception e)
        {
            return 0;
        }
    }

    public int delcit(int pkPGraduationCollege)
    {
        try
        {
            return g.del(pkPGraduationCollege);
        }
        catch (Exception e)
        {
            return 0;
        }
    }
    public DataTable fetch(int pkPGraduationCollege)
    {
        return g.fetc(pkPGraduationCollege);
    }

}