﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;
using System.Collections.Specialized;


namespace BusinessLogic
{
    /// <summary>
    /// Summary description for SubmitScheduleDataLogic
    /// </summary>
    public class SubmitScheduleDataLogic
    {
        private int _pkScheduleId;
        private int _fkDoctorId;
        private int _Day;
        private int _FromTime;
        private int _ToTime;
        private string _Place;
        public SubmitScheduleDataLogic(int pkScheduleId, int fkDoctorId, int Day, int day, int FromTime, int ToTime, string Place)
        {
            _pkScheduleId = pkScheduleId;
            _fkDoctorId = fkDoctorId;
            _Day = Day;
            _FromTime = FromTime;
            _ToTime = ToTime;
            _Place = Place;
        }

        public SubmitScheduleDataLogic()
        {

        }

        #region get-set property
        /// <summary>
        /// get-set property
        /// </summary>
         public int pkScheduleId
        {
            get
            {
                return _pkScheduleId;
            }
            set
            {
                _pkScheduleId = value;
            }
        }

        public int fkDoctorId
        {
            get
            {
                return _fkDoctorId;
            }
            set
            {
                _fkDoctorId = value;
            }
        }

        public int Day
        {
            get
            {
                return _Day;
            }
            set
            {
                _Day = value;
            }
        }

       
        public int FromTime
        {
            get
            {
                return _FromTime;
            }
            set
            {
                _FromTime = value;
            }
        }
        public int ToTime
        {
            get
            {
                return _ToTime;
            }
            set
            {
                _ToTime = value;
            }
        }
        public string Place
        {
            get
            {
                return _Place;
            }
            set
            {
                _Place = value;
            }
        }

        #endregion

        #region Submit Data
        /// <summary>
        /// Submit DataLogic
        /// </summary>
        /// <param name="Day"></param>
        /// <param name="FromTime"></param>
        /// <param name="ToTime"></param>
        /// <param name="Place"></param>
        public void SubmitDataLogic(int Day, int FromTime, int ToTime, string Place)
        {
            try
            {
                SubmitScheduleDataAccess d1 = new SubmitScheduleDataAccess();
                d1.SubmitDataAccess(this._Day, this._FromTime, this._ToTime, this._Place);

            }
            catch (Exception e)
            {

            }
        }
        #endregion
    }
}