﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Patient_Profile_bl
/// </summary>
public class Patient_Profile_bl
{
    Patient_Profile_da pt = new Patient_Profile_da();

    private int _pkPatientId;
    private string _FirstName;
    private string _LastName;
    private string _DateOfBirth;
    private string _Gender;
    private string _Email;
    private string _BloodGroup;
    private string _Street1;
    private string _Street2;
    private int _fkCityId;
    private Int64 _PinCode;
    private int _fkStateId;
    private int _fkCountryId;
    private Int64 _ContactNumber;
    private string _SpecificDetail;
    private int _fkRegistrationId;

	public Patient_Profile_bl()
	{
	}

    public Patient_Profile_bl(int fkRegid)
    {
        _fkRegistrationId = fkRegid;
    }

    public int pkPatientId
    {
        get
        {
            return _pkPatientId;
        }
        set
        {
            _pkPatientId = pkPatientId;
        }
    }

    public string FirstName
    {
        get
        {
            return _FirstName;
        }
        set
        {
            _FirstName = value;
        }
    }

    public string LastName
    {
        get
        {
            return _LastName;
        }
        set
        {
            _LastName = value;
        }
    }

    public string DateOfBirth
    {
        get
        {
            return _DateOfBirth;
        }
        set
        {
            _DateOfBirth = value;
        }
    }

    public string Gender
    {
        get
        {
            return _Gender;
        }
        set
        {
            _Gender = value;
        }
    }

    public string BloodGroup
    {
        get
        {
            return _BloodGroup;
        }
        set
        {
            _BloodGroup = value;
        }
    }

    public string Email
    {
        get
        {
            return _Email;
        }
        set
        {
            _Email = value;
        }
    }

    
    public string Street1
    {
        get
        {
            return _Street1;
        }
        set
        {
            _Street1 = value;
        }
    }

    public string Street2
    {
        get
        {
            return _Street2;
        }
        set
        {
            _Street2 = value;
        }
    }

    public int fkCityId
    {
        get
        {
            return _fkCityId;
        }
        set
        {
            _fkCityId = value;
        }
    }

    public int fkCountryId
    {
        get
        {
            return _fkCountryId;
        }
        set
        {
            _fkCountryId = value;
        }
    }

    public int fkStateId
    {
        get
        {
            return _fkStateId;
        }
        set
        {
            _fkStateId = value;
        }
    }

    public Int64 PinCode
    {
        get
        {
            return _PinCode;
        }
        set
        {
            _PinCode = value;
        }
    }
    public Int64 ContactNumber
    {
        get
        {
            return _ContactNumber;
        }
        set
        {
            _ContactNumber = value;
        }
    }

    public string SpecificDetail
    {
        get
        {
            return _SpecificDetail;
        }
        set
        {
            _SpecificDetail = value;
        }
    }

    public int fkRegistrationId
    {
        get
        {
            return _fkRegistrationId;
        }
        set
        {
            _fkRegistrationId = fkRegistrationId;
        }
    }


    public void display(int fkRegistrationId)
    {
        pt.ptprofile(fkRegistrationId);
    }
}