﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;


namespace BusinessLogic
{
    /// <summary>
    /// Summary description for DoctorRegistrationSubmitLogic
    /// </summary>
    public class DoctorRegistrationSubmitLogic
    {
        private string _UserName;
        private int _fkUserTypeId;
        private string _FirstName;
        private string _LastName;
        private int _fkSpecialityId;
        private string _DateOfBirth;
        private string _Gender;
        private string _BloodGroup;
        private string _Email;
        private string _Password;
        private int _fkqueid;
        private string _ans;
        private string _Street1;
        private string _Street2;
        private int _fkCityId;
        private int _fkCountryId;
        private int _fkStateId;
        private int _PinCode;
        private Int64 _ContactNumber;
        private string _Photo;
        private int _fkDoctorId;
        private int _Graduation_Year;
        private int _Graduation_College;
        private int _PG_Year;
        private int _PG_College;

        public DoctorRegistrationSubmitLogic(string UserName, int fkUserTypeId, string FirstName, string LastName, int fkSpecialityId, string DateOfBirth, string Gender, string BloodGroup, string Email, string Password, int fkqueid, string ans, string Street1, string Street2, int fkCityId, int fkCountryId, int fkStateId, int PinCode, Int64 ContactNumber, string Photo, int fkDoctorId, int Graduation_Year, int Graduation_College, int PG_Year, int PG_College)
        {
            _UserName = UserName;
            _fkUserTypeId = fkUserTypeId;
            _FirstName = FirstName;
            _LastName = LastName;
            _fkSpecialityId = fkSpecialityId;
            _DateOfBirth = DateOfBirth;
            _Gender = Gender;
            _BloodGroup = BloodGroup;
            _Email = Email;
            _Password = Password;
            _fkqueid = fkqueid;
            _ans = ans;
            _Street1 = Street1;
            _Street2 = Street2;
            _fkCityId = fkCityId;
            _fkCountryId = fkCountryId;
            _fkStateId = fkStateId;
            _PinCode = PinCode;
            _ContactNumber = ContactNumber;
            _Photo = Photo;
            _fkDoctorId = fkDoctorId;
            _Graduation_Year = Graduation_Year;
            _Graduation_College = Graduation_College;
            _PG_Year = PG_Year;
            _PG_College = PG_College;
        }
        public DoctorRegistrationSubmitLogic()
        {

        }

        public string UserName
        {
            get
            {
                return _UserName;
            }
            set
            {
                _UserName = value;
            }
        }

        public int fkUserTypeId
        {
            get
            {
                return _fkUserTypeId;
            }
            set
            {
                _fkUserTypeId = value;
            }
        }

        public string FirstName
        {
            get
            {
                return _FirstName;
            }
            set
            {
                _FirstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return _LastName;
            }
            set
            {
                _LastName = value;
            }
        }

        public int fkSpecialityId
        {
            get
            {
                return _fkSpecialityId;
            }
            set
            {
                _fkSpecialityId = value;
            }
        }

        public string DateOfBirth
        {
            get
            {
                return _DateOfBirth;
            }
            set
            {
                _DateOfBirth = value;
            }
        }

        public string Gender
        {
            get
            {
                return _Gender;
            }
            set
            {
                _Gender = value;
            }
        }

        public string BloodGroup
        {
            get
            {
                return _BloodGroup;
            }
            set
            {
                _BloodGroup = value;
            }
        }

        public string Email
        {
            get
            {
                return _Email;
            }
            set
            {
                _Email = value;
            }
        }

        public string Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }

        public string Street1
        {
            get
            {
                return _Street1;
            }
            set
            {
                _Street1 = value;
            }
        }

        public string Street2
        {
            get
            {
                return _Street2;
            }
            set
            {
                _Street2 = value;
            }
        }

        public int fkCityId
        {
            get
            {
                return _fkCityId;
            }
            set
            {
                _fkCityId = value;
            }
        }

        public int fkCountryId
        {
            get
            {
                return _fkCountryId;
            }
            set
            {
                _fkCountryId = value;
            }
        }

        public int fkStateId
        {
            get
            {
                return _fkStateId;
            }
            set
            {
                _fkStateId = value;
            }
        }

        public int PinCode
        {
            get
            {
                return _PinCode;
            }
            set
            {
                _PinCode = value;
            }
        }
        public Int64 ContactNumber
        {
            get
            {
                return _ContactNumber;
            }
            set
            {
                _ContactNumber = value;
            }
        }

        public string Photo
        {
            get
            {
                return _Photo;
            }
            set
            {
                _Photo = value;
            }
        }

        public int fkDoctorId
        {
            get
            {
                return _fkDoctorId;
            }
            set
            {
                _fkDoctorId = value;
            }
        }
        public int Graduation_Year
        {
            get
            {
                return _Graduation_Year;
            }
            set
            {
                _Graduation_Year = value;
            }
        }
        public int Graduation_College
        {
            get
            {
                return _Graduation_College;
            }
            set
            {
                _Graduation_College = value;
            }
        }

        public int PG_Year
        {
            get
            {
                return _PG_Year;
            }
            set
            {
                _PG_Year = value;
            }
        }
        public int PG_College
        {
            get
            {
                return _PG_College;
            }
            set
            {
                _PG_College = value;
            }
        }

        public int fkqueid
        {
            get
            {
                return _fkqueid;
            }
            set
            {
                _fkqueid = value;
            }
        }

        public string ans
        {
            get
            {
                return _ans;
            }
            set
            {
                _ans = value;
            }
        }
        public void DoctorRegistrationLogic(string UserName, int fkUserTypeId, string FirstName, string LastName, int fkSpecialityId, string DateOfBirth, string Gender, string BloodGroup, string Email, string Password, int fkqueid, string ans, string Street1, string Street2, int fkCityId, int fkCountryId, int fkStateId, int PinCode, Int64 ContactNumber, string Photo, int Graduation_Year, int Graduation_College, int PG_Year, int PG_College)
        {
            try
            {
                DoctorRegistrationDataAccess d = new DoctorRegistrationDataAccess();
                d.DoctorRegistrationData(this._UserName, this._fkUserTypeId, this._FirstName, this._LastName, this._fkSpecialityId, this._DateOfBirth, this._Gender, this._BloodGroup, this._Email, this._Password, this._fkqueid, this._ans, this._Street1, this._Street2, this._fkCityId, this._fkCountryId, this._fkStateId, this._PinCode, this._ContactNumber, this._Photo, this._Graduation_Year, this._Graduation_College, this._PG_Year, this._PG_College);
            }
            catch (Exception e)
            {

            }
        }
    }
}