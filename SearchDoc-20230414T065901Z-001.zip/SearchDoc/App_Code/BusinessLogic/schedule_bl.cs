﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for schedule_bl
/// </summary>
public class schedule_bl
{
    schedule_dl dl = new schedule_dl();
    DataTable dt = new DataTable();

    private Int32 _fkDayId;
    private Int32 _FromTime;
    private Int32 _ToTime;
    private Int32 _fkhospitalId;
    //private string _Area;
    private Int32 _fkCityId;
    private Int32 _fkStateId;
    private Int32 _fkRegistrationId;
    private Int32 _pkScheduleId;
    private int _fkDrId;

    public schedule_bl()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public schedule_bl(int fkDayId, int FromTime, int ToTime, int fkhospitalId, int fkRegistrationId, int fkCityId, int fkStateId)
        {
            //_pkScheduleId = pkScheduleId;
            //_fkDoctorId = fkDoctorId;
            _fkDayId = fkDayId;
            _FromTime = FromTime;
            _ToTime = ToTime;
            _fkhospitalId = fkhospitalId;
            _fkRegistrationId = fkRegistrationId;
           // _Area = Area;
            _fkCityId = fkCityId;
            _fkStateId = fkStateId;
           
        }

    public schedule_bl(int pkScheduleId,int fkdrId)
    {
       _pkScheduleId = pkScheduleId;
       _fkDrId = fkdrId;
    }

    //public schedule_bl(int fkdrId)
    //{
        
    //    _fkDrId = fkdrId;
    //}

    public int fkdrId
    {
        get
        {
            return _fkDrId;
        }
        set
        {
            _fkDrId = value;
        }
    }
    
    public Int32 pkScheduleId
    {
        get
        {
            return _pkScheduleId;
        }
        set
        {
            _pkScheduleId = value;
        }
    }
    public Int32 fkRegistrationId
    {
        get
        {
            return _fkRegistrationId;
        }
        set
        {
            _fkRegistrationId = value;
        }
    }

    public Int32 fkDayId
    {
        get
        {
            return _fkDayId;
        }
        set
        {
            _fkDayId = value;
        }
    }


    public Int32 FromTime
    {
        get
        {
            return _FromTime;
        }
        set
        {
            _FromTime = value;
        }
    }
    public Int32 ToTime
    {
        get
        {
            return _ToTime;
        }
        set
        {
            _ToTime = value;
        }
    }
    public Int32 fkhospitalId
    {
        get
        {
            return _fkhospitalId;
        }
        set
        {
            _fkhospitalId = value;
        }
    }

    public Int32 fkCityId
    {
        get
        {
            return _fkCityId;
        }
        set
        {
            _fkCityId = value;
        }
    }

    public Int32 fkStateId
    {
        get
        {
            return _fkStateId;
        }
        set
        {
            _fkStateId = value;
        }
    }

    public void AddSchedule()
    {
        try
        {
            dl.schedule(this._fkDayId, this._FromTime, this._ToTime, this._fkhospitalId,this._fkRegistrationId, this._fkCityId, this._fkStateId,this._fkDrId);

        }
        catch (Exception e)
        {

        }
    }


    public void updtSchedule(int pkScheduleId)
    {
        try
        {
            dl.updtschedule(pkScheduleId, this._fkDayId, this._FromTime, this._ToTime, this._fkhospitalId, this._fkRegistrationId, this._fkCityId, this._fkStateId);
        }
        catch (Exception e)
        {

        }
    }

    public DataTable fetch(int pkScheduleId)
    {
        return dl.fetc(pkScheduleId);
    }

    public DataTable fetchd(int fkdrId)
    {
        try
        {
            return dl.fetcd(fkdrId);
        }
        catch (Exception e)
        {
            return null;
        }
    }
    public int delschedule(int pkScheduleId)
    {
        try
        {
            return dl.del(pkScheduleId);
        }
        catch (Exception e)
        {
            return 0;
        }
    }
}