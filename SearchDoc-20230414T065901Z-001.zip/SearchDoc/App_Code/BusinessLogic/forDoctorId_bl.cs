﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
/// <summary>
/// Summary description for forDoctorId_bl
/// </summary>
public class forDoctorId_bl
{
    forDoctorId dr = new forDoctorId();

    private int _fkRegistrationId;
	public forDoctorId_bl()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public forDoctorId_bl(int fkRegistrationId)
    {
        _fkRegistrationId = fkRegistrationId;
    }

    public int fkRegistrationId
    {
        get
        {
            return _fkRegistrationId;
        }
        set
        {
            _fkRegistrationId = value;
        }

    }
    public int drid()
    {
        return (dr.doctorId(this._fkRegistrationId));
    }

}