﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;

/// <summary>
/// Summary description for UpdateScheduleLogic
/// </summary>
/// 
namespace BusinessLogic
{
        public class UpdateScheduleLogic
        {
            private int _pkScheduleId;
            private int _fkDoctorId;
            private int _fkDayId;
            private int _FromTime;
            private int _ToTime;
            private string _Place;

        public UpdateScheduleLogic(int pkScheduleId, int fkDoctorId, int Day, int FromTime, int ToTime, string Place)
        {
            _pkScheduleId = pkScheduleId;
            _fkDoctorId = fkDoctorId;
            _fkDayId = fkDayId;
            _FromTime = FromTime;
            _ToTime = ToTime;
            _Place = Place;
        }
        public UpdateScheduleLogic()
        { 
       
        }

        #region get-set property
        /// <summary>
            /// get-set property
            /// </summary>
        public int pkScheduleId
        {
            get
            {
                return _pkScheduleId;
            }
            set
            {
                _pkScheduleId = value;
            }
        }

        public int fkDoctorId
        {
            get
            {
                return _fkDoctorId;
            }
            set
            {
                _fkDoctorId = value;
            }
        }
        public int fkDayId
        {
            get
            {
                return _fkDayId;
            }
            set
            {
                _fkDayId = value;
            }
        }
        public int FromTime
        {
            get
            {
                return _FromTime;
            }
            set
            {
                _FromTime = value;
            }
        }
        public int ToTime
        {
            get
            {
                return _ToTime;
            }
            set
            {
                _ToTime = value;
            }
        }
        public string Place
        {
            get
            {
                return _Place;
            }
            set
            {
                _Place = value;
            }
        }

        #endregion

        #region Update Schedule logic
        /// <summary>
            /// update schedule logic
            /// </summary>
            /// <param name="pkScheduleId"></param>
            /// <param name="fkDayId"></param>
            /// <param name="FromTime"></param>
            /// <param name="ToTime"></param>
            /// <param name="Place"></param>
        public void updateschedulelogic(int pkScheduleId,int fkDayId, int FromTime, int ToTime, string Place)
        {
            try
            {
                UpdateScheduleDataAccess d1 = new UpdateScheduleDataAccess();
                d1.updatescheduledata(this._pkScheduleId,this._fkDayId, this._FromTime, this._ToTime, this._Place);

            }
            catch (Exception e)
            { 
          
            }
        }
        #endregion
        }
}
    