﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
/// <summary>
/// Summary description for City
/// </summary>
public class City
{
    City_db ct = new City_db();

    private int _pkCityID;
    private string _Cityi;
    private int _fkStateID;

    public City()
    {
    }

    public City(int pkCityID, string Cityi, int fkStateID)
    {
        _pkCityID = pkCityID;
        _Cityi = Cityi;
        _fkStateID = fkStateID;
    }

    public City(string Cityi, int fkStateID)
    {
        _Cityi = Cityi;
        _fkStateID = fkStateID;
    }

    public City(int pkCityID)
    {
        _pkCityID = pkCityID;
    }

    public int pkCityID
    {
        get
        {
            return _pkCityID;
        }
        set
        {
            _pkCityID = value;
        }
    }

    public string Cityi
    {
        get
        {
            return _Cityi;
        }
        set
        {
            _Cityi = value;
        }
    }

    public int fkStateID
    {
        get
        {
            return _fkStateID;
        }
        set
        {
            _fkStateID = value;
        }
    }

    public int inscit()
    {
        try
        {
            return ct.inscity(this._Cityi, this._fkStateID);
        }
        catch (Exception e)
        {
            return 0;
        }
    }

    public int updtcit(int pkCityID)
    {
        try
        {
            return ct.updtcity(pkCityID, this._Cityi, this._fkStateID);
        }
        catch (Exception e)
        {
            return 0;
        }
    }

    public int delcit(int pkCityID)
    {
        try
        {
            return ct.delcity(pkCityID);
        }
        catch (Exception e)
        {
            return 0;
        }
    }
    public DataTable fetch(int pkCityID)
    {
        return ct.fetc(pkCityID);
    }

    public DataTable dis()
    {
        return ct.display();
    }
   
}