﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Dr_Updt_bl
/// </summary>
public class Dr_Updt_bl
{
    Dr_Updt_da drupdt = new Dr_Updt_da();
    private string _FirstName;
    private string _LastName;
    private string _DateOfBirth;
    private string _Gender;
    private string _Email;
    private string _BloodGroup;
    private string _Street1;
    private string _Street2;
    private int _fkCityId;
    private Int64 _PinCode;
    private int _fkStateId;
    private int _fkCountryId;
    private Int64 _ContactNumber;
    private string _SpecificDetail;
    private int _fkRegistrationId;
    private int _fkSpecialityId;

    private int _Graduation_Year;
    private int _Graduation_College;
    private int _PG_Year;
    private int _PG_College;

	public Dr_Updt_bl()
	{
	}

    public Dr_Updt_bl(string fname, string lname,int fkSpecialityId, string dob, string gender, string email, string bg, string street1, string street2, int fkCityid, Int64 pin, int fkStateId, int fkCountryId, Int64 mb, int fkRegistrationId, int Graduation_Year, int Graduation_College, int PG_Year, int PG_College)
    {

        _FirstName = fname;
        _LastName = lname;
        _DateOfBirth = dob;
        _Gender = gender;
        _Email = email;
        _BloodGroup = bg;
        _Street1 = street1;
        _Street2 = street2;
        _fkCityId = fkCityid;
        _PinCode = pin;
        _fkStateId = fkStateId;
        _fkCountryId = fkCountryId;
        _ContactNumber = mb;
        _fkSpecialityId = fkSpecialityId;

        _fkRegistrationId = fkRegistrationId;

        _Graduation_Year = Graduation_Year;
        _Graduation_College = Graduation_College;
        _PG_Year = PG_Year;
        _PG_College = PG_College;
    }

    public int Graduation_Year
    {
        get
        {
            return _Graduation_Year;
        }
        set
        {
            _Graduation_Year = value;
        }
    }
    public int Graduation_College
    {
        get
        {
            return _Graduation_College;
        }
        set
        {
            _Graduation_College = value;
        }
    }

    public int PG_Year
    {
        get
        {
            return _PG_Year;
        }
        set
        {
            _PG_Year = value;
        }
    }
    public int PG_College
    {
        get
        {
            return _PG_College;
        }
        set
        {
            _PG_College = value;
        }
    }

    public int fkSpecialityId
    {
        get
        {
            return _fkSpecialityId;
        }
        set
        {
            _fkSpecialityId = value;
        }
    }

    public string FirstName
    {
        get
        {
            return _FirstName;
        }
        set
        {
            _FirstName = value;
        }
    }

    public string LastName
    {
        get
        {
            return _LastName;
        }
        set
        {
            _LastName = value;
        }
    }

    public string DateOfBirth
    {
        get
        {
            return _DateOfBirth;
        }
        set
        {
            _DateOfBirth = value;
        }
    }

    public string Gender
    {
        get
        {
            return _Gender;
        }
        set
        {
            _Gender = value;
        }
    }

    public string BloodGroup
    {
        get
        {
            return _BloodGroup;
        }
        set
        {
            _BloodGroup = value;
        }
    }

    public string Email
    {
        get
        {
            return _Email;
        }
        set
        {
            _Email = value;
        }
    }


    public string Street1
    {
        get
        {
            return _Street1;
        }
        set
        {
            _Street1 = value;
        }
    }

    public string Street2
    {
        get
        {
            return _Street2;
        }
        set
        {
            _Street2 = value;
        }
    }

    public int fkCityId
    {
        get
        {
            return _fkCityId;
        }
        set
        {
            _fkCityId = value;
        }
    }

    public int fkCountryId
    {
        get
        {
            return _fkCountryId;
        }
        set
        {
            _fkCountryId = value;
        }
    }

    public int fkStateId
    {
        get
        {
            return _fkStateId;
        }
        set
        {
            _fkStateId = value;
        }
    }

    public Int64 PinCode
    {
        get
        {
            return _PinCode;
        }
        set
        {
            _PinCode = value;
        }
    }
    public Int64 ContactNumber
    {
        get
        {
            return _ContactNumber;
        }
        set
        {
            _ContactNumber = value;
        }
    }

    public string SpecificDetail
    {
        get
        {
            return _SpecificDetail;
        }
        set
        {
            _SpecificDetail = value;
        }
    }

    public int updt(int fkRegistrationId)
    {
        return (drupdt.dr_updt(this._FirstName, this._LastName,this._fkSpecialityId,this._DateOfBirth, this._Email, this._Gender, this._BloodGroup, this._Street1, this._Street2, this._fkCityId, this._PinCode, this._fkStateId, this._fkCountryId, this._ContactNumber,fkRegistrationId,this._Graduation_Year,this._Graduation_College,this._PG_College,this._PG_College));
    }


}