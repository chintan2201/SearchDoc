﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DataAccess;



namespace BusinessLogic
{
    /// <summary>
    /// Summary description for UpdateDayLogic
    /// </summary>
    public class UpdateDayLogic
    {
        public int _Day;
        public int _fkRegistrationId;
        public UpdateDayLogic(int Day,int fkRegistrationId)
        {
            _Day = Day;
            _fkRegistrationId = fkRegistrationId;
        }

        public UpdateDayLogic()
        {
        
        }

        public int Day
        {
            get
            {
                return _Day;
            }
            set
            {
                _Day = value;
            }
        }

        public int fkRegistrationId
        {
            get
            {
                return _fkRegistrationId;
            }
            set
            {
                _fkRegistrationId = value;
            }
        }

        public DataTable DayLogic(int Day, int fkRegistrationId)
        {
            try
            {
                UpdateDayData d = new UpdateDayData();
                return d.DayData(this._Day,this._fkRegistrationId);
            }
            catch (Exception e)
            {
                return null;
            }
        }
    }
}